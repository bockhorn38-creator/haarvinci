# HaarVinci-Homepage 1.0.0 – Prüfnachweis

Prüfung am **11. November 2026**, ausschließlich fiktive Formular-Testeingaben. Bereitgestellte Originalporträts, Studiofotos und bestätigte Geschäftsinhalte werden ausschließlich in dieser privaten Testfassung verwendet. Keine Veröffentlichung auf IONOS oder in einem öffentlichen Git-Zweig.

## Erfolgreiche Prüfungen

- Statischer Astro-Build mit vier HTML-Seiten: Start, Impressumsentwurf, Datenschutzentwurf und 404. Kein Node-/Python-/Datenbankdienst für die spätere Auslieferung erforderlich. TypeScript/Astro-Prüfung ohne Fehler, Warnungen oder Hinweise; Prettier vollständig erfolgreich.
- **18 echte Chromium-/Playwright-Prüfungen bestanden.** Geprüft wird der gebaute Stand aus `dist/`, nicht nur die Entwicklungsvorschau. Der vollständige Browserlauf ist lokal mit `npm run build`, `npm run export:preview`, `npm test` reproduzierbar.
- Alle Hauptbereiche und Anker, deutsche Metadaten, genau eine Hauptüberschrift, Vorschau-Indexierungssperre, rechtliche Entwurfsseiten und tatsächliche 404-Antwort geprüft.
- Bestätigte Preise explizit mit der Preisliste verglichen: 80/160/220 €, jede weitere Reihe 65 €, Zusatzintegration 35 €, Neuset-Vorbereitung 40 €, Entfernung 20/35/45 €, Form-/Spitzenanpassung 20 €, Pony 15 €, Styling 20 €, Mehraufwand nach Aufwand. Neuset-Beispiel 340 €. Kein automatisches zusätzliches Entfernen beim Hochsetzen, keine automatische Neuset-Gebühr bei jedem Nachsetzen, Haarmaterial separat.
- Fünfstufigen Ablauf einschließlich vollständiger Material-Vorauszahlung, Bestellung, verbindlicher Terminvereinbarung und separater Dienstleistungsabrechnung geprüft. Methode auf Cornrow-Basis, mögliche Mikroringe zum Sichern der Enden und keine unbestätigte „mikroringfreie“ Behauptung.
- **Sieben Bildschirmbreiten: 360, 390, 412, 600, 760, 1024 und 1440 Pixel.** Alle Bereiche ohne horizontalen Überlauf. Mobile Navigation öffnen/schließen, nach Navigation schließen und Escape/Fokus geprüft. Desktop-/Pixel- und Preisansicht zusätzlich visuell anhand tatsächlicher Browser-Screenshots kontrolliert.
- FAQ mit Tastatur und exklusiv geöffnetem Eintrag; Studio-Großansicht mit tatsächlichem Bild, Escape und Fokusrückgabe erfolgreich. Bewegungseinstellung `prefers-reduced-motion` berücksichtigt. Alle verwendeten Inhaltsbilder laden und haben Größenangaben/Alternativtexte.
- **Axe: keine Befunde im geprüften WCAG-2-A/AA- und 2.1-A/AA-Regelsatz**, sowohl auf der Hauptseite als auch im geöffneten mobilen Menü und auf den Rechtsentwürfen. Das ersetzt keine vollständige manuelle Barrierefreiheitsprüfung.
- Anfragehelfer: fehlender Name, Fokus/Fehlermeldung, fiktive Unicode-/Sonderzeicheneingaben, sichere URL-Kodierung, korrektes WhatsApp-Ziel und korrekte E-Mail-Adresse samt Betreff/Text. Öffnungsaktionen werden im Test abgefangen; keine echten Nachrichten an Conny gesendet. Es wird kein Versand behauptet, und die eingegebenen Daten werden nicht auf der Website gespeichert.
- Keine Cookies, kein LocalStorage, kein SessionStorage, keine Iframes und **keine externen Hintergrundabrufe** beim Seitenaufruf. Schriften/Bilder/JavaScript werden lokal ausgeliefert. Ohne JavaScript bleiben Inhalte, Navigation und direkte Kontakte nutzbar.
- Originalbilder anhand SHA-256 gegen den Herkunftsnachweis geprüft. Keine KI-Porträts, privaten Smartphone-Screenshots oder erfundenen Vorher-Nachher-Ergebnisse eingebaut. Ergebnisliste anfangs leer; kein leerer Ergebnis-CTA und kein Galerie-Platzhalter.
- **Vollständig eingebettete HTML-Vorschau erfolgreich geprüft:** Navigation, Formularvorbereitung, geladene Bilder und Rechtsseiten funktionieren ohne zusätzliche Bild-/Schrift-/Skriptanfragen. Prüfung mit unterbundenem Netz und aus den tatsächlichen HTML-Dateien erfüllten lokalen Seitenantworten; keine Ersatzoberfläche.
- **Freigabesperre und Freigabebuild geprüft:** Bei fehlenden Freigaben/Rechtstexten bricht die Freigabeprüfung ab. Positiver Pfad in einem getrennten temporären Projekt mit ausschließlich technischen Testmarkern: echte Inhaltsdateien werden eingebaut, Entwurfskennzeichnungen verschwinden, Canonical/Indexierungsangaben und robots.txt stimmen. Die eigentliche interne Fassung und ihre Freigabeschalter werden dabei nicht verändert. Die technischen Marker werden anschließend entfernt und niemals als Rechtstexte ausgeliefert.

## Konkrete Grenzen

- Der verwaltete Cloud-Chromium sperrt direkte `file://`-Navigation mit **`ERR_BLOCKED_BY_ADMINISTRATOR`**. Dieser direkte Versuch ist dokumentiert fehlgeschlagen; er wird nicht als bestandene Windows-/Doppelklickprüfung ausgegeben. Der vollständig eingebettete Inhalt wurde stattdessen wie oben über erlaubte lokale Seitenantworten geprüft. Den tatsächlichen Doppelklick einmal auf dem privaten Windows-Rechner testen.
- Kein physischer Windows-/Pixel-Test der Website in dieser Sitzung. Bitte insbesondere die tatsächliche Zuordnung von WhatsApp, Telefon- und E-Mail-Links zu den dort installierten Programmen prüfen. Ein korrekt vorbereiteter Text ist noch keine versendete Nachricht.
- Die bestätigten Instagram-/Maps-/Bewertungslinks werden korrekt ausgegeben, aber es wurde kein öffentliches Profil, Eintrag oder Bewertungstext geändert. Keine erfolgreiche Zustellung einer E-Mail behauptet.
- Kein Live-Hosting-/IONOS-/DNS-/Mail-/HTTPS-Umstellungstest; nichts am vorhandenen Vertrag oder Baukasten geändert. Die enthaltene `.htaccess` ist für eine spätere Prüfung auf dem tatsächlichen Apache-Webhosting vorbereitet.
- Die neue GitHub-Website-Prüfung ist vorbereitet. Sie wurde noch nicht remote ausgeführt, weil dieser Stand mit den noch nicht zur Veröffentlichung freigegebenen Fotos lokal bleibt. Erfolgsnachweise hier stammen von den tatsächlich ausgeführten lokalen Prüfungen.

## Vor einem öffentlichen Livegang

Vollständige geprüfte Rechtsinhalte, endgültige Bild-/Logo-/Textfreigaben und ausdrückliche Veröffentlichungsgenehmigung einholen. Bisherige Geschäftsangaben final bestätigen. Echte Ergebnisfotos später nur mit ausdrücklicher Freigabe ergänzen; bis dahin bleibt die Ergebnisgalerie ausgeblendet. Vollständiger Ablauf in [README.md](README.md).

Die Verwaltungs-App, ihre Datenbanken und die vorhandenen Android-/Windows-Funktionen wurden für die Website nicht verändert. Alle neuen Website-Quellen liegen getrennt unter `website/`.
