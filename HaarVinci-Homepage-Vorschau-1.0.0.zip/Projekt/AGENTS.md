# Öffentliche HaarVinci-Website

- Eigenständiges statisches Astro-Projekt; die Android-/Windows-/Django-App im übergeordneten Verzeichnis nicht umbauen.
- Maßgebliche Inhalte: vom Nutzer autorisiertes Website-Briefing vom 10.11.2026. Marke exakt HaarVinci. Keine eigenen Qualifikationen, Heilversprechen, Preise oder Ergebnisse erfinden.
- Echte bereitgestellte Geschäfts-/Porträt-/Studioinhalte sind für die lokale Gestaltung autorisiert. Keine Kundenakten oder echten Kundendaten aus der Verwaltungs-App übernehmen. Keine KI-Porträts oder erfundenen Ergebnisse.
- Originale unter assets-source unverändert erhalten; scripts/prepare-assets.mjs erstellt ausschließlich optimierte Auslieferungen ohne KI-Veränderung und ohne Übernahme privater Bildmetadaten.
- Veröffentlichung (auch öffentlicher Git-Push von Fotos) erst nach geklärten Freigaben und vollständigen Rechtstexten. Für diesen Auftrag lokal bauen, prüfen, dokumentieren und committen. Keine IONOS-/DNS-/Vertragsänderungen.
- npm ci; npm run check; npm run build; npm test. Tests prüfen den tatsächlichen statischen Build mit Chromium, Kontaktlinks, Tastatur, responsive Darstellung und Barrierefreiheit.
- Keine extern geladenen Schriftarten, Tracker, Datenbank, Formulardienst oder angeblichen Versanderfolge. Kontakt nur als bewusst geöffnete Telefon-/WhatsApp-/E-Mail-Anfrage.
