# HaarVinci · Homepage 1.0.0

Eigenständige öffentliche Website für Conny in Kiel. **Aktueller Stand: vollständig bedienbare interne Testfassung, noch nicht für den öffentlichen Livegang freigegeben.** Maßgebliche Inhaltsgrundlage: [Briefing vom 10.11.2026](briefing/BRIEFING_2026-11-10.md).

## Ohne Entwicklungsprogramme ansehen

Das bereitgestellte Vorschau-ZIP vollständig entpacken. Dann **`HaarVinci-Vorschau.html` doppelt anklicken** und in einem aktuellen Chrome, Edge oder Firefox öffnen. Die beigefügten Dateien `Impressum.html`, `Datenschutz.html` und `404.html` im selben Ordner lassen.

Diese gesonderte Offline-Vorschau enthält Bilder, Schriften, Gestaltung und JavaScript direkt in den HTML-Dateien. Für das Ansehen, Navigation, FAQ und Studio-Galerie ist kein Server und kein Internet erforderlich. WhatsApp, Telefon- und E-Mail-Aktionen verwenden die dafür auf deinem Gerät eingerichteten Programme; WhatsApp und externe Links benötigen eine Verbindung. Keine Nachricht wird automatisch versendet.

Die Offline-Vorschau ist ausschließlich zur privaten Abstimmung gedacht. Sie ist kein Hostingpaket und ersetzt keine Veröffentlichungsgenehmigung. Der reguläre statische Build liegt separat unter `Webhosting-Dateien/` im Paket.

Prüfgrenze: Der verwaltete Cloud-Browser sperrt direkte `file://`-Navigation mit `ERR_BLOCKED_BY_ADMINISTRATOR`. Die vollständig eingebetteten Seiten wurden deshalb über erlaubtes lokales HTTP ohne zusätzliche Ressourcenabrufe geprüft. Der tatsächliche Doppelklick und die Zuordnung zum WhatsApp-/E-Mail-Programm müssen einmal auf deinem Windows-Rechner ausprobiert werden. Falls dort ebenfalls eine Organisationsrichtlinie lokale HTML-Dateien sperrt, die reguläre Vorschau mit `npm run preview` verwenden.

## Entwickeln und lokal starten

Voraussetzung: **Node.js 24 LTS** mit npm (mindestens Node 22.23.4). Keine Datenbank, kein Python, kein Cloud-Account, kein dauerhaft laufender Node-Server für das spätere Hosting.

Im Ordner `website` beziehungsweise `Projekt` des Vorschaupakets:

```bash
npm ci
npm run dev
```

`http://localhost:4321` öffnen. Normalerweise beendet `Strg+C` die Vorschau. Astro kann in Agentenumgebungen im Hintergrund starten; dort mit `npx astro dev status` prüfen und mit `npx astro dev stop` beenden. Für einen ausdrücklich im Vordergrund laufenden Entwicklungsserver: `npm run dev -- --ignore-lock`. Telemetrie wird durch den lokalen CLI-Wrapper deaktiviert.

## Optimierten statischen Build erzeugen

```bash
npm run check
npm run build
npm run preview
```

`dist/` enthält ausschließlich auslieferbare HTML-, CSS-, Bild-, Schrift- und Lizenzdateien. `npm run preview -- --port 4321 --ignore-lock` startet die Build-Vorschau im Vordergrund. `npm run export:preview` erzeugt danach zusätzlich die serverfreie private Doppelklick-Ansicht unter `offline-preview/`. Der Hostingbuild wird dabei nicht verändert.

`npm ci` verwendet exakt `package-lock.json` einschließlich Paket-Integritätswerten. `npm run assets` erzeugt responsive WebP-Größen aus sechs unveränderten Originalmotiven und entfernt private EXIF-/GPS-Metadaten in der Auslieferung. Originale und Herkunftsprüfsummen bleiben erhalten. Keine KI-Veränderung, keine Vergrößerung über die Originalauflösung. Beide Schriftfamilien werden lokal mit den OFL-Lizenztexten ausgeliefert.

## Was funktioniert

- Responsive Startseite mit exakter Marke **HaarVinci**, warmem Editorial-Design, originaler Schriftmarke, echten Porträts und Studiofotos.
- Leistungen für Länge, Fülle und individuelle Oberkopflösungen. Fachlich erklärte Weaving-Methode auf Cornrow-Basis, einschließlich möglicher Mikroringe zum Sichern der Enden. Eigenhaargesundheit als Arbeitsprinzip; keine Schadensfreiheitsgarantie.
- Vollständige bestätigte Preisübersicht als HTML: Basis/Hochsetzen, optionale Leistungen, eigener Entfernungstermin, Zusatzmodule und eingeordnetes Neuset-Beispiel von 340 €. Keine doppelte Entfernung, keine automatische Neuset-Gebühr, Haarmaterial separat.
- Fünfstufiger Beratungs-/Bestellablauf mit vollständiger Material-Vorauszahlung vor Bestellung und verbindlicher Terminvereinbarung. Keine automatische Terminbestätigung.
- Persönliche Geschichte von Conny, echte Studio-Galerie mit Großansicht und 19 FAQ-Antworten auf Basis des Briefings.
- Tastaturbedienbare mobile Navigation, native aufklappbare Fragen, Foto-Dialog mit Escape und Fokusrückgabe. Reduzierte Bewegung wird respektiert. Ohne JavaScript bleiben Inhalte, Navigation und direkte Kontakte nutzbar.
- Bestätigte Telefon-/WhatsApp-/E-Mail-, Instagram-, Anfahrts- und Bewertungslinks. Keine eingebettete Karte, keine Widgets oder externen Fonts.
- Optionaler Anfragehelfer: Name, Anliegen, Zeitfenster, Rückkontakt und freie Nachricht. Prüft Eingaben, bereitet einen sicher kodierten Text vor und öffnet den bewusst gewählten Kommunikationskanal. Falls eine App nicht startet, bleibt ein erneuter Öffnungslink verfügbar. Kein Backendversand, keine Erfolgstäuschung und keine Speicherung in Cookies, LocalStorage oder einer Datenbank.
- Impressum und Datenschutz als eigene technische Seiten. In der internen Fassung ausdrücklich Entwürfe, keine erfundenen Pflichtangaben. Eigene 404-Seite und Vorschau-Indexierungssperre.

## Ergebnisse später ergänzen

`src/data/results.ts` enthält eine typisierte, anfangs leere Ergebnisliste. Deshalb erscheinen weder erfundene Vorher-Nachher-Fotos noch leere Galerieplatzhalter oder ein ins Leere führender Ergebnis-CTA. Sobald echte Bilder samt ausdrücklicher Freigabe vorliegen, können sie mit Ausgangslage, Wunsch, tatsächlich ausgeführter Behandlung und Alternativtexten ergänzt werden. Die Galerie und der Hero-CTA werden dann automatisch sichtbar.

Die KI-Bildentwürfe und privaten Smartphone-Screenshots wurden nicht in die Website übernommen. Der alte 0.1-Prototyp wurde eingesehen; diese Implementierung ist ein eigenständiges Astro-Projekt.

## Inhalte ändern und später erweitern

- `src/data/site.ts`: bestätigte Kontakte, Preisgruppen und FAQ; Beträge sind die aktuelle Website-Preisliste und ändern keine Tarife der Verwaltungs-App.
- `src/pages/index.astro`: Seitenstruktur, persönliche Geschichte und erklärende Texte.
- `src/components/`: Navigation/Layout, Bildausgabe, Preistabelle, Kontakt und Rechtsseiten.
- `assets-source/` und `HERKUNFT.json`: unveränderte Ausgangsmotive und Zuordnung.
- `scripts/prepare-assets.mjs`: responsive Bildauslieferung und Schriftlizenzen.
- `src/styles/global.css`: Gestaltung und responsive Typografie.
- `content/release.json` und `content/legal/`: spätere, bewusst freizugebende öffentliche Fassung.

Website und Verwaltungs-App sind getrennt. Es werden keine Kundenakten importiert, App-Datenbanken geöffnet oder Kalender-/Login-/APK-Funktionen verändert. Künftige Etappen können an die vorhandenen Inhaltsdaten und Komponenten anknüpfen. KI-Assistent, Kundenkonto, Haarpass und Android-Synchronisierung sind in Etappe 1 nicht implementiert und werden nicht als fertige Menüpunkte vorgetäuscht.

## Automatisierte Prüfungen

```bash
npm run check
npm run format:check
npm run build
npm run export:preview
npm test
```

Die Tests verwenden den tatsächlich gebauten statischen Stand, keine Attrappen. Standard in dieser Cloud: `/usr/bin/chromium`. Andernorts `CHROMIUM_PATH` auf die lokale Browserdatei setzen oder Playwrights Browser installieren:

```bash
npx playwright install chromium
```

Dann unter Windows PowerShell `$env:CHROMIUM_PATH="playwright"` setzen (Linux/macOS: `CHROMIUM_PATH=playwright npm test`). Der Testserver verwendet ausschließlich `127.0.0.1:4322`. Alle Formulareingaben in den Tests sind fiktiv. Öffnen von WhatsApp/E-Mail wird abgefangen; es werden keine Nachrichten an Conny gesendet. Die konkrete App-Zuordnung auf dem privaten Gerät bleibt eine manuelle Prüfung.

Geprüft werden Preise und fachliche Abgrenzungen, alle Bereiche/Anker, sieben Breiten von 360 bis 1440 Pixeln, Tastatur, Menü, FAQ, Foto-Dialog, Formularfehler, Unicode/URL-Kodierung, E-Mail-/WhatsApp-Ziel, keine Speicherung/externen Hintergrundabrufe, funktionierende Bilder, reduzierte Bewegung, Rechtsseiten/404, Originalprüfsummen, Offline-Dateivorschau und Freigabebuild. Axe prüft WCAG 2 A/AA und 2.1 A/AA; das ersetzt keine vollständige manuelle Barrierefreiheitsprüfung.

Der Freigabepfad wird zusätzlich in einem isolierten temporären Ordner mit ausdrücklich technischen Testmarkern geprüft. Diese Marker sind keine Rechtstexte, werden niemals in `dist/` des eigentlichen Projekts geschrieben und sind nicht Bestandteil des gelieferten Vorschaupakets.

## Veröffentlichungssperren und IONOS

Vor einem öffentlichen Livegang sind erforderlich:

1. Vollständiges Impressum und vollständige Datenschutzerklärung von der verantwortlichen Betreiberin bereitstellen und für den tatsächlichen Betrieb prüfen. Rechtlicher vollständiger Name und weitere einschlägige Pflichtangaben fehlen. Dateien als `content/legal/impressum.html` und `datenschutz.html` ablegen; reine Inhaltsfragmente ohne eigene HTML-Grundstruktur oder Skripte.
2. Veröffentlichung der verwendeten Porträts, Studiofotos und Logos sowie der finalen Texte bestätigen. Aus dem Upload wird keine öffentliche Freigabe abgeleitet. Das gilt auch für einen öffentlichen Git-Push der Bilddateien.
3. Als „bisheriger Stand“ markierte Geschäftsangaben final abgleichen. Die Homepage verwendet keine unbestätigte Erfahrungsdauer, Beratungsminutenzahl oder feste Lieferwochen. Kostenloses Beratungsangebot und Angebotsumfang vor Livegang nochmals bestätigen.
4. Fehlende Ergebnisfotos sind keine Pflicht zur Erfindung: Galerie bis zu einer gesondert freigegebenen Auswahl ausgeblendet lassen. Zitate von Kundinnen oder Bewertungen werden ebenfalls erst nach geklärter Verwendung ergänzt.
5. Öffentliche Veröffentlichung ausdrücklich freigeben und alle tatsächlichen Freigaben in `content/release.json` auf `true` setzen. Eine technische Markierung ersetzt die inhaltliche/rechtliche Prüfung nicht.

Erst danach `npm run build:release` ausführen. Ohne Freigaben oder Rechtstextdateien bricht dieser Befehl mit einer konkreten Liste ab. Im Freigabebuild werden die tatsächlichen Texte eingebaut, Vorschaukennzeichnungen entfernt und reguläre Indexierungs-/Canonical-Angaben erzeugt. Die aktuelle interne Testfassung bleibt dabei unverändert, solange kein solcher bewusster Build ausgeführt wird. `noindex` und `robots.txt` sind kein Zugriffsschutz.

Später **nur den Inhalt des freigegebenen `dist/`** in das passende IONOS-Webverzeichnis laden, einschließlich `_astro/`, `medien/`, `lizenzen/`, `robots.txt` und gegebenenfalls `.htaccess`. Nicht `node_modules/`, Originalfotos, Briefing oder Quellcode hochladen. Die Apache-Hinweise in `.htaccess`, HTTPS, kanonische Domain und tatsächliche 404-Ausgabe auf dem gebuchten Hosting prüfen. Keine DNS-, Mail-, Vertrags- oder Baukastenänderung wurde vorgenommen; `haarvinci.de` und `info@haarvinci.de` bleiben bei IONOS.

Quellcode wird lokal in Git gesichert. Weil die Bildfreigaben und Rechtstexte für die öffentliche Veröffentlichung fehlen, wird diese Website-Fassung nicht automatisch in das bisher öffentliche GitHub-Repository gepusht.
