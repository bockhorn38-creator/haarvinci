# Verwendete Drittbestandteile

Manrope und Cormorant Garamond werden über Fontsource bezogen und ausschließlich lokal ausgeliefert. Beide Schriftfamilien stehen unter der SIL Open Font License 1.1. Die vollständigen Lizenztexte werden beim Build unverändert nach `dist/lizenzen/` kopiert und dem privaten Vorschaupaket beigelegt. Es findet kein Abruf bei Google Fonts statt.

Astro und Sharp sowie Entwicklungswerkzeuge werden über npm mit festgehaltenen Integritätswerten in `package-lock.json` installiert. Ihre vollständigen Lizenzangaben liegen in den jeweiligen npm-Paketen. Die Website lädt zur Laufzeit keine fremden JavaScript-Bibliotheken nach.

Die sechs ausgewählten Originalbilder einschließlich Schriftmarke stammen aus dem vom Nutzer bereitgestellten HaarVinci-Paket. Die Zuordnung und SHA-256-Prüfsummen stehen in `assets-source/HERKUNFT.json`. Diese Herkunftsangabe ersetzt keine Veröffentlichungsfreigabe. KI-Entwürfe, private Smartphone-Screenshots und Fotos von Kundinnen wurden nicht übernommen.
