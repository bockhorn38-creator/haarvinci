import { defineConfig } from 'astro/config';

// Statische Dateien für reguläres Webhosting; keine Server-/Cloud-Adapter.
export default defineConfig({
  site: 'https://haarvinci.de',
  output: 'static',
  trailingSlash: 'always',
  build: { format: 'directory' },
  vite: { build: { sourcemap: false } },
});
