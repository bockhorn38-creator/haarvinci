# Hier später die freigegebenen Rechtstexte ablegen

Benötigt werden `impressum.html` und `datenschutz.html` als geprüfte HTML-Inhaltsfragmente ohne `<html>`, `<head>`, `<body>` oder Skripte. Die Seitenüberschrift wird von der Website vorgegeben. Bis zur tatsächlichen Bereitstellung bleiben diese Dateien bewusst abwesend und der Freigabebuild gesperrt.

Die intern sichtbaren Entwurfsseiten sind keine veröffentlichungsfähigen Rechtstexte. Die technischen Testmarker des isolierten Tests gehören niemals hierher.
