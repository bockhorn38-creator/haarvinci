import './check-release.mjs';
import { spawnSync } from 'node:child_process';
import fs from 'node:fs';

for (const args of [
  ['scripts/prepare-assets.mjs'],
  ['node_modules/astro/bin/astro.mjs', 'build'],
]) {
  const result = spawnSync(process.execPath, args, {
    stdio: 'inherit',
    env: { ...process.env, HAARVINCI_RELEASE: 'true', ASTRO_TELEMETRY_DISABLED: '1' },
  });
  if (result.status !== 0) process.exit(result.status || 1);
}
fs.writeFileSync('dist/robots.txt', 'User-agent: *\nAllow: /\n');
