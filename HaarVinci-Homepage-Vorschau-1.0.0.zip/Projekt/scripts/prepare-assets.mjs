import sharp from 'sharp';
import fs from 'node:fs/promises';
import { createHash } from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = fileURLToPath(new URL('../', import.meta.url));
const sources = {
  schriftzug: 'logo-schwarz.png',
  'conny-sonnenlicht': 'conny-portraet.jpg',
  'conny-persoenlich': 'conny-persoenlich.jpg',
  'studio-arbeitsplatz': 'studio-arbeitsplatz.jpg',
  'studio-uebersicht': 'studio-uebersicht.jpg',
  'studio-einblick': 'studio-einblick.jpg',
};
const target = path.join(root, 'public/medien');
await fs.mkdir(target, { recursive: true });
const manifest = {};
for (const [key, filename] of Object.entries(sources)) {
  const source = await fs.readFile(path.join(root, 'assets-source', filename));
  const metadata = await sharp(source).metadata();
  const rotated = [5, 6, 7, 8].includes(metadata.orientation);
  const width = rotated ? metadata.height : metadata.width;
  const height = rotated ? metadata.width : metadata.height;
  const widths = [...new Set([360, 540, 690, 960, 1280, 1536].map((w) => Math.min(w, width)))].sort(
    (a, b) => a - b,
  );
  const variants = [];
  for (const size of widths) {
    const name = `${key}-${size}.webp`;
    // Sharp entfernt EXIF/XMP/GPS standardmäßig. Keine Retusche oder KI-Veränderung.
    await sharp(source)
      .rotate()
      .resize({ width: size, withoutEnlargement: true })
      .webp({ quality: 88, effort: 6 })
      .toFile(path.join(target, name));
    variants.push({ src: `/medien/${name}`, width: size });
  }
  manifest[key] = {
    width,
    height,
    src: variants.at(-1).src,
    srcset: variants.map((v) => `${v.src} ${v.width}w`).join(', '),
    source_sha256: createHash('sha256').update(source).digest('hex'),
  };
}
await fs.writeFile(
  path.join(root, 'src/data/media.json'),
  JSON.stringify(manifest, null, 2) + '\n',
);
await fs.mkdir(path.join(root, 'public/lizenzen'), { recursive: true });
for (const [packageName, name] of [
  ['@fontsource-variable/manrope', 'Manrope-OFL.txt'],
  ['@fontsource/cormorant-garamond', 'Cormorant-Garamond-OFL.txt'],
]) {
  await fs.copyFile(
    path.join(root, 'node_modules', packageName, 'LICENSE'),
    path.join(root, 'public/lizenzen', name),
  );
}
console.log(
  '6 unveränderte Originalmotive; responsive WebP-Auslieferung ohne private Metadaten bereit.',
);
