export type Result = {
  id: string;
  title: string;
  before: string;
  after: string;
  beforeAlt: string;
  afterAlt: string;
  description: string;
  publicationApproved: true;
};

// Erst echte, ausdrücklich freigegebene Kundenergebnisse ergänzen.
// Eine leere Liste erzeugt weder Galerie-Platzhalter noch einen leeren CTA.
export const results: Result[] = [];
