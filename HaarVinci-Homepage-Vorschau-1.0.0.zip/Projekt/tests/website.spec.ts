import { test, expect } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';
import { execFileSync } from 'node:child_process';
import {
  readFileSync,
  existsSync,
  mkdtempSync,
  cpSync,
  symlinkSync,
  writeFileSync,
  rmSync,
} from 'node:fs';
import { createHash } from 'node:crypto';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';

test('vollständige statische Homepage, ausschließlich lokale Ressourcen und korrekte Links', async ({
  page,
  context,
}) => {
  const errors: string[] = [];
  const external: string[] = [];
  page.on('pageerror', (e) => errors.push(e.message));
  page.on('response', (r) => {
    if (r.status() >= 400) errors.push(`${r.status()} ${r.url()}`);
  });
  page.on('request', (r) => {
    if (r.url().startsWith('http') && !r.url().startsWith('http://127.0.0.1:4322/'))
      external.push(r.url());
  });
  await page.goto('/');
  await page.evaluate(() => document.fonts.ready);
  await expect(page).toHaveTitle(/HaarVinci.*Haarverlängerung.*Kiel/);
  await expect(page.locator('html')).toHaveAttribute('lang', 'de');
  await expect(page.locator('h1')).toHaveCount(1);
  await expect(page.locator('meta[name=description]')).toHaveAttribute(
    'content',
    /Eigenhaar|Haargesundheit/,
  );
  await expect(page.locator('meta[name=robots]')).toHaveAttribute('content', /noindex/);
  for (const id of [
    'leistungen',
    'methode',
    'beratung',
    'preise',
    'conny',
    'studio',
    'fragen',
    'kontakt',
  ])
    await expect(page.locator(`#${id}`)).toBeAttached();
  const missing = await page
    .locator('a[href^="#"]')
    .evaluateAll((links) =>
      links
        .map((a) => a.getAttribute('href')!)
        .filter((href) => !document.getElementById(href.slice(1))),
    );
  expect(missing).toEqual([]);
  await expect(page.getByRole('link', { name: 'Ergebnisse ansehen' })).toHaveCount(0);
  await expect(page.locator('#ergebnisse')).toHaveCount(0);
  await expect(page.locator('iframe')).toHaveCount(0);
  await expect(page.getByRole('link', { name: 'WhatsApp schreiben', exact: true })).toHaveAttribute(
    'href',
    'https://wa.me/4917631600586',
  );
  await expect(
    page.getByRole('link', { name: '0176 31600586', exact: true }).first(),
  ).toHaveAttribute('href', 'tel:+4917631600586');
  await expect(
    page.getByRole('link', { name: 'info@haarvinci.de', exact: true }).first(),
  ).toHaveAttribute('href', 'mailto:info@haarvinci.de');
  expect(
    await page
      .locator('a[target=_blank]')
      .evaluateAll((links) => links.every((a) => a.getAttribute('rel')?.includes('noopener'))),
  ).toBe(true);
  expect(await context.cookies()).toEqual([]);
  expect(await page.evaluate(() => localStorage.length)).toBe(0);
  expect(await page.evaluate(() => sessionStorage.length)).toBe(0);
  expect(external).toEqual([]);
  expect(errors).toEqual([]);
});

test('bestätigte Preise, Abgrenzungen und fünf Schritte ohne erfundene Ergebnisse', async ({
  page,
}) => {
  await page.goto('/');
  const base = page.getByRole('table', { name: 'Basis-Service / Hochsetzen', exact: true });
  for (const [name, price] of [
    ['1 Reihe', '80 €'],
    ['2 Reihen insgesamt', '160 €'],
    ['3 Reihen insgesamt', '220 €'],
    ['Jede weitere Reihe', '65 €'],
  ])
    await expect(base.getByRole('row').filter({ hasText: name })).toContainText(price);
  const extra = page.getByRole('table', { name: 'Optional beim Hochsetzen' });
  await expect(extra.getByRole('row').filter({ hasText: 'Zusatzintegration' })).toContainText(
    '35 €',
  );
  await expect(extra.getByRole('row').filter({ hasText: 'neuen Haarsatzes' })).toContainText(
    '40 €',
  );
  const remove = page.getByRole('table', { name: 'Entfernen · eigener Termin' });
  for (const [name, price] of [
    ['1 Reihe', '20 €'],
    ['2 Reihen', '35 €'],
    ['3 Reihen', '45 €'],
  ])
    await expect(remove.getByRole('row').filter({ hasText: name })).toContainText(price);
  const modules = page.getByRole('table', { name: 'Zusatzmodule' });
  for (const [name, price] of [
    ['Form- und Spitzenanpassung', '20 €'],
    ['Ponyschneiden', '15 €'],
    ['Styling', '20 €'],
    ['Sonderwünsche', 'nach Aufwand'],
  ])
    await expect(modules.getByRole('row').filter({ hasText: name })).toContainText(price);
  await expect(page.locator('.price-example')).toContainText('340 €');
  await expect(page.locator('#preise')).toContainText('nicht automatisch zusätzlich');
  await expect(page.locator('#preise')).toContainText('nicht automatisch bei jedem Nachsetztermin');
  await expect(page.locator('#beratung .journey>li')).toHaveCount(5);
  await expect(page.locator('#beratung .journey>li').nth(2)).toContainText(
    'vollständigen Haarpreis',
  );
  await expect(page.locator('#beratung .journey>li').nth(3)).toContainText('Nach Bezahlung');
  await expect(page.locator('#methode')).toContainText('kleine Mikroringe');
  expect(
    await page
      .locator('img')
      .evaluateAll((images) => images.every((img) => !/ki_|beispiel|stock/i.test(img.src))),
  ).toBe(true);
  await expect(page.locator('body')).not.toContainText('über zehn Jahre');
  await expect(page.locator('body')).not.toContainText('mikroringfrei');
});

for (const width of [360, 390, 412, 600, 760, 1024, 1440]) {
  test(`Darstellung und Bedienung bei ${width} Pixeln`, async ({ page }) => {
    await page.setViewportSize({ width, height: 920 });
    await page.goto('/');
    await page.evaluate(() => document.fonts.ready);
    for (const id of [
      'leistungen',
      'methode',
      'beratung',
      'preise',
      'conny',
      'studio',
      'fragen',
      'kontakt',
    ]) {
      await page.locator(`#${id}`).scrollIntoViewIfNeeded();
      expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(
        true,
      );
    }
    await page.evaluate(() => window.scrollTo(0, 0));
    if (width < 1100) {
      const menu = page.getByRole('button', { name: 'Menü', exact: true });
      await expect(menu).toBeVisible();
      await expect(page.getByRole('navigation', { name: 'Hauptnavigation' })).toBeHidden();
      await menu.click();
      await expect(menu).toHaveAttribute('aria-expanded', 'true');
      await page
        .getByRole('navigation', { name: 'Hauptnavigation' })
        .getByRole('link', { name: 'Preise', exact: true })
        .click();
      await expect(menu).toHaveAttribute('aria-expanded', 'false');
      await menu.click();
      await page.keyboard.press('Escape');
      await expect(menu).toBeFocused();
      await expect(menu).toHaveAttribute('aria-expanded', 'false');
    } else await expect(page.getByRole('navigation', { name: 'Hauptnavigation' })).toBeVisible();
    if ([412, 1440].includes(width)) {
      await page.evaluate(() => window.scrollTo(0, 0));
      await page.screenshot({ path: `test-results/haarvinci-${width}.png`, fullPage: true });
    }
  });
}

test('FAQ mit Tastatur, Studio-Dialog mit Escape und Fokusrückgabe', async ({ page }) => {
  await page.goto('/');
  const faq = page.locator('.faq-list details').first();
  await faq.locator('summary').focus();
  await page.keyboard.press('Enter');
  await expect(faq).toHaveAttribute('open', '');
  const next = page.locator('.faq-list details').nth(1);
  await next.locator('summary').click();
  await expect(next).toHaveAttribute('open', '');
  await expect(faq).not.toHaveAttribute('open', '');
  const photo = page.getByRole('button', { name: /Studiofoto groß ansehen/ }).first();
  await photo.click();
  await expect(page.getByRole('dialog')).toBeVisible();
  await expect(page.getByRole('button', { name: 'Studiofoto schließen' })).toBeFocused();
  await expect(page.locator('#studio-dialog-image')).toHaveAttribute('src', /studio-uebersicht/);
  await page.keyboard.press('Escape');
  await expect(page.getByRole('dialog')).not.toBeVisible();
  await expect(photo).toBeFocused();
});

test('Anfrage: Pflichtfeld, Unicode und sichere URL-Kodierung ohne automatische Nachricht', async ({
  page,
}) => {
  await page.addInitScript(() => {
    (window as any).opened = [];
    window.open = ((url: string) => {
      (window as any).opened.push(url);
      return null;
    }) as typeof window.open;
  });
  await page.goto('/');
  const whatsapp = page.getByRole('button', { name: 'In WhatsApp öffnen' });
  await whatsapp.click();
  await expect(page.locator('#anfrage-fehler')).toBeVisible();
  await expect(page.getByLabel('Dein Name')).toBeFocused();
  expect(await page.evaluate(() => (window as any).opened)).toEqual([]);
  await page.getByLabel('Dein Name').fill('Nele Fiktiv & Test');
  await page.getByLabel('Dein Anliegen').selectOption({ label: 'Haarverdichtung' });
  await page.getByLabel('Dein Zeitfenster').fill('Dienstag nach 15 Uhr');
  await page
    .getByLabel('Deine Nachricht')
    .fill('Fiktive Anfrage: Locken & Fülle ❤️ <script>alert(1)</script>');
  await whatsapp.click();
  const opened = await page.evaluate(() => (window as any).opened as string[]);
  expect(opened).toHaveLength(1);
  const url = new URL(opened[0]);
  expect(url.origin + url.pathname).toBe('https://wa.me/4917631600586');
  expect(url.searchParams.get('text')).toContain('Nele Fiktiv & Test');
  expect(url.searchParams.get('text')).toContain('Haarverdichtung');
  expect(url.searchParams.get('text')).toContain('❤️ <script>');
  await expect(page.locator('#anfrage-vorbereitet')).toContainText(
    'noch keine Nachricht versendet',
  );
  await expect(page.locator('#anfrage-link')).toHaveAttribute('href', opened[0]);
  expect(page.url()).not.toContain('Nele');
  await page.getByRole('button', { name: 'Als E-Mail öffnen' }).click();
  const email = await page.locator('#anfrage-link').getAttribute('href');
  expect(email).toContain('mailto:info@haarvinci.de?subject=');
  expect(new URL(email!).searchParams.get('body')).toContain('Nele Fiktiv & Test');
  await page.reload();
  await expect(page.getByLabel('Dein Name')).toHaveValue('');
});

test('ohne JavaScript bleiben Inhalte, Navigation und direkte Kontakte nutzbar', async ({
  browser,
}) => {
  const context = await browser.newContext({
    javaScriptEnabled: false,
    viewport: { width: 390, height: 900 },
  });
  const page = await context.newPage();
  await page.goto('http://127.0.0.1:4322/');
  await expect(page.getByRole('navigation', { name: 'Hauptnavigation' })).toBeVisible();
  await expect(page.getByRole('link', { name: 'WhatsApp schreiben', exact: true })).toBeVisible();
  await expect(page.locator('#anfrage')).toBeHidden();
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  await context.close();
});

test('barrierearme Hauptseite und geöffnete mobile Navigation ohne ernste Axe-Befunde', async ({
  page,
}) => {
  await page.goto('/');
  await page.evaluate(() => document.fonts.ready);
  let results = await new AxeBuilder({ page })
    .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'])
    .analyze();
  expect(
    results.violations.map((v) => ({ id: v.id, targets: v.nodes.map((n) => n.target) })),
  ).toEqual([]);
  await page.setViewportSize({ width: 390, height: 900 });
  await page.getByRole('button', { name: 'Menü', exact: true }).click();
  results = await new AxeBuilder({ page })
    .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'])
    .analyze();
  expect(
    results.violations.map((v) => ({ id: v.id, targets: v.nodes.map((n) => n.target) })),
  ).toEqual([]);
});

test('Rechtsseiten sind ausdrücklich Entwürfe, 404 und Veröffentlichungssperre funktionieren', async ({
  page,
  request,
}) => {
  for (const name of ['impressum', 'datenschutz']) {
    const response = await page.goto(`/${name}/`);
    expect(response?.status()).toBe(200);
    await expect(page.locator('h1')).toHaveCount(1);
    await expect(page.locator('h1')).toContainText('Entwurf');
    await expect(page.locator('main')).toContainText('nicht öffentlich veröffentlicht');
    await page.setViewportSize({ width: 360, height: 900 });
    expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(
      true,
    );
    const results = await new AxeBuilder({ page })
      .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'])
      .analyze();
    expect(results.violations).toEqual([]);
  }
  const response = await page.goto('/diese-seite-gibt-es-nicht/');
  expect(response?.status()).toBe(404);
  await expect(page.getByRole('link', { name: 'Zur Startseite', exact: true })).toBeVisible();
  expect((await request.get('/robots.txt')).status()).toBe(200);
  expect(await (await request.get('/robots.txt')).text()).toContain('Disallow: /');
  expect(() =>
    execFileSync(process.execPath, ['scripts/check-release.mjs'], { stdio: 'pipe' }),
  ).toThrow();
});

test('unveränderte Originale und vollständiger statischer Build ohne Kundendaten', async () => {
  const manifest = JSON.parse(readFileSync('assets-source/HERKUNFT.json', 'utf8'));
  for (const [name, data] of Object.entries(manifest) as [string, { sha256: string }][]) {
    expect(
      createHash('sha256')
        .update(readFileSync('assets-source/' + name))
        .digest('hex'),
    ).toBe(data.sha256);
  }
  for (const name of [
    'index.html',
    'impressum/index.html',
    'datenschutz/index.html',
    '404.html',
    'robots.txt',
    'favicon.svg',
  ])
    expect(existsSync('dist/' + name)).toBe(true);
  const text = readFileSync('dist/index.html', 'utf8');
  for (const value of ['localhost:800', '/kundinnen/', 'haarvinci_android_gate'])
    expect(text).not.toContain(value);
});

test('reduzierte Bewegung wird berücksichtigt und die Bilder laden', async ({ page }) => {
  await page.emulateMedia({ reducedMotion: 'reduce' });
  await page.goto('/');
  expect(await page.evaluate(() => getComputedStyle(document.documentElement).scrollBehavior)).toBe(
    'auto',
  );
  for (const image of await page.locator('main img[width][height]').all()) {
    await image.scrollIntoViewIfNeeded();
    await expect(image).toHaveJSProperty('complete', true);
    expect(await image.evaluate((img: HTMLImageElement) => img.naturalWidth)).toBeGreaterThan(0);
    await expect(image).toHaveAttribute('width', /\d+/);
    await expect(image).toHaveAttribute('height', /\d+/);
  }
});

test('eingebettete Vorschau funktioniert ohne zusätzliche Ressourcen oder externe Netzabrufe', async ({
  page,
  context,
}) => {
  await context.setOffline(true);
  const pages = new Set([
    'HaarVinci-Vorschau.html',
    'Impressum.html',
    'Datenschutz.html',
    '404.html',
  ]);
  await context.route('http://127.0.0.1:4322/offline/*.html', async (route) => {
    const name = new URL(route.request().url()).pathname.split('/').at(-1)!;
    if (!pages.has(name)) throw new Error('Unerwartete Vorschauseite');
    await route.fulfill({ path: resolve('offline-preview', name), contentType: 'text/html' });
  });
  const requests: string[] = [];
  page.on('request', (request) => {
    if (request.url().startsWith('http')) requests.push(request.resourceType());
  });
  await page.addInitScript(() => {
    (window as any).opened = [];
    window.open = ((url: string) => {
      (window as any).opened.push(url);
      return null;
    }) as typeof window.open;
  });
  const errors: string[] = [];
  page.on('pageerror', (e) => errors.push(e.message));
  await page.setViewportSize({ width: 412, height: 920 });
  await page.goto('/offline/HaarVinci-Vorschau.html');
  await page.evaluate(() => document.fonts.ready);
  await expect(page.getByRole('heading', { name: /Mehr Länge/ })).toBeVisible();
  await page.getByRole('button', { name: 'Menü', exact: true }).click();
  await page
    .getByRole('navigation', { name: 'Hauptnavigation' })
    .getByRole('link', { name: 'Preise', exact: true })
    .click();
  await expect(page.locator('.menu-toggle')).toHaveAttribute('aria-expanded', 'false');
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  await page.getByLabel('Dein Name').fill('Nele Offlinefiktiv');
  await page.getByRole('button', { name: 'In WhatsApp öffnen' }).click();
  expect(await page.evaluate(() => (window as any).opened[0])).toContain(
    'https://wa.me/4917631600586?text=',
  );
  await expect(page.locator('#anfrage-vorbereitet')).toContainText(
    'noch keine Nachricht versendet',
  );
  for (const img of await page.locator('main img[width]').all()) {
    await img.scrollIntoViewIfNeeded();
    await expect(img).toHaveJSProperty('complete', true);
    expect(await img.evaluate((image: HTMLImageElement) => image.naturalWidth)).toBeGreaterThan(0);
  }
  await page.getByRole('link', { name: 'Impressum · Entwurf', exact: true }).click();
  await expect(page.locator('h1')).toContainText('Impressum');
  await expect(page.locator('h1')).toContainText('Entwurf');
  await page.getByRole('link', { name: 'Zurück zur Website', exact: true }).click();
  await expect(page.locator('h1')).toContainText('Mehr Länge');
  expect(errors).toEqual([]);
  expect(requests.every((type) => type === 'document')).toBe(true);
});

test('Freigabebuild verwendet echte Textdateien und verändert nie die interne Vorschau', async () => {
  const temporary = mkdtempSync(join(tmpdir(), 'haarvinci-release-fixture-'));
  try {
    for (const file of [
      'src',
      'public',
      'scripts',
      'assets-source',
      'content',
      'astro.config.mjs',
      'tsconfig.json',
      'package.json',
    ])
      cpSync(file, join(temporary, file), { recursive: true });
    symlinkSync(
      resolve('node_modules'),
      join(temporary, 'node_modules'),
      process.platform === 'win32' ? 'junction' : 'dir',
    );
    // Ausschließlich technische Marker im temporären Testordner, keine erfundenen Rechtstexte.
    const flags = JSON.parse(readFileSync('content/release.json', 'utf8'));
    writeFileSync(
      join(temporary, 'content/release.json'),
      JSON.stringify(Object.fromEntries(Object.keys(flags).map((key) => [key, true]))),
    );
    for (const name of ['impressum', 'datenschutz'])
      writeFileSync(
        join(temporary, `content/legal/${name}.html`),
        `<p>Automatischer Testmarker ${name}, kein Rechtstext und nicht zur Veröffentlichung bestimmt.</p>`,
      );
    execFileSync(process.execPath, ['scripts/build-release.mjs'], {
      cwd: temporary,
      env: { ...process.env, ASTRO_TELEMETRY_DISABLED: '1' },
      stdio: 'pipe',
      timeout: 30_000,
    });
    const home = readFileSync(join(temporary, 'dist/index.html'), 'utf8');
    expect(home).not.toContain('Persönliche Website-Vorschau');
    expect(home).toContain('index, follow');
    expect(home).toContain('https://haarvinci.de/');
    const legal = readFileSync(join(temporary, 'dist/impressum/index.html'), 'utf8');
    expect(legal).toContain('Automatischer Testmarker impressum');
    expect(legal).not.toContain('noch nicht vor');
    expect(readFileSync(join(temporary, 'dist/robots.txt'), 'utf8')).toContain('Allow: /');
    expect(readFileSync('dist/index.html', 'utf8')).toContain('noindex, nofollow');
    expect(Object.values(JSON.parse(readFileSync('content/release.json', 'utf8')))).toEqual(
      Object.values(flags),
    );
  } finally {
    rmSync(temporary, { recursive: true, force: true });
  }
});
