# Öffentliche HaarVinci-Website

- Eigenständiges statisches Astro-Projekt; die Android-/Windows-/Django-App im übergeordneten Verzeichnis nicht umbauen.
- Maßgebliche Inhalte: vom Nutzer autorisiertes Website-Briefing vom 10.11.2026. Marke exakt HaarVinci. Keine eigenen Qualifikationen, Heilversprechen, Preise oder Ergebnisse erfinden.
- Echte bereitgestellte Geschäfts-/Porträt-/Studioinhalte sind für die Gestaltung autorisiert. Der Zusatzauftrag zu Version 1.0 gibt außerdem ausdrücklich `Ueber_Conny_Gestaltungsentwurf.png` für den Conny-Bereich frei. Diesen nur technisch zuschneiden/optimieren, Gesicht nicht retuschieren oder neu generieren. Andere KI-Porträts und erfundene Ergebnisse bleiben ausgeschlossen. Keine Kundenakten aus der Verwaltungs-App übernehmen.
- Originale unter assets-source unverändert erhalten; scripts/prepare-assets.mjs erstellt ausschließlich optimierte Auslieferungen ohne KI-Veränderung und ohne Übernahme privater Bildmetadaten.
- Der Nutzer hat den öffentlichen Download des vollständigen Vorschau-ZIPs einschließlich Fotos ausdrücklich freigegeben; aktualisierte geprüfte ZIPs dürfen im vorhandenen Download-Zweig ergänzt werden. Alte Downloads erhalten. Ein Livegang bei IONOS benötigt weiterhin vollständige Rechtstexte und die separate Freigabe. Keine IONOS-/DNS-/Vertragsänderungen.
- npm ci; npm run check; npm run build; npm test. Tests prüfen den tatsächlichen statischen Build mit Chromium, Kontaktlinks, Tastatur, responsive Darstellung und Barrierefreiheit.
- Keine extern geladenen Schriftarten, Tracker, Datenbank, Formulardienst oder angeblichen Versanderfolge. Kontakt nur als bewusst geöffnete Telefon-/WhatsApp-/E-Mail-Anfrage.

- Reel-Zusatzauftrag: echte bereitgestellte Reels sind als Standbildquelle autorisiert. Auswahl und Zeitpunkte in assets-source/REEL-AUSWAHL.json, Herkunft in HERKUNFT.json. Keine erfundenen Vorher-Nachher-Paare, keine Retusche von Haarergebnissen, keine MP4-Dateien oder Instagram-Einbettungen ausliefern. Reel 04 liegt wegen der 32-MiB-Übertragungsgrenze nicht lokal vor; Conny-Arbeitsmoment stammt aus Reel 02.
