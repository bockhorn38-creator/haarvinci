# CODEX – ZUSATZAUFTRAG REELS / ECHTE MEDIEN FUER HAARVINCI

## Ziel

Nutze die neu bereitgestellten echten HaarVinci-Reels von Conny als Materialbasis fuer die naechste Verbesserung der Homepage. Die Videos sollen **vorerst nicht direkt als eingebettete Reels** in die Website uebernommen werden. Stattdessen sollen aus ihnen geeignete Bilder, Vorschau-Elemente und inhaltliche Bereiche fuer die Website entstehen.

## Verfuegbares Material

Ordner:

- `videos/`
- `storyboards/`

Dateien:

1. `01_reel_extensions_rot.mp4`
2. `02_reel_behandlung_und_ergebnis.mp4`
3. `03_reel_glanz_und_laenge.mp4`
4. `04_reel_conny_produkterklaerung.mp4`

Zu jedem Reel liegt ein Storyboard/Kontaktbogen im Ordner `storyboards/` vor.

## Wichtige Einordnung

Alle hochgeladenen Reels stammen laut Projektstand von Conny bzw. zeigen echte HaarVinci-Arbeiten. Trotzdem sollen sie fuer Version 1.0 und 1.1 zunaechst **kontrolliert und hochwertig** eingesetzt werden, damit die Website elegant bleibt.

## Deine Aufgabe

Arbeite die bestehenden echten Medien in das vorhandene Homepage-Projekt ein.

### 1. Medien sichten und auswaehlen

Pruefe die vier Reels und waehle geeignete Szenen/Frames fuer die Website aus.

Ziel:

- nur hochwertige, ruhige, klare Bilder verwenden
- keine unscharfen oder hektischen Momente
- keine Frames mit stoerenden Textoverlays verwenden, wenn bessere Alternativen verfuegbar sind
- bei Bedarf mehrere Frames pro Reel exportieren und optimieren

### 2. Neue Website-Bereiche mit echtem Material verbessern

Nutze die Reels fuer folgende Bereiche:

#### A. Ergebnisse

Ergaenze oder verbessere den Bereich „Ergebnisse“ mit echten Frames aus den Reels.

Besonders geeignet:

- `01_reel_extensions_rot.mp4`
- `03_reel_glanz_und_laenge.mp4`

Ziel:

- mehr Laenge
- mehr Fuelle
- Glanz und natuerliches Finish
- echte Resultate sichtbar machen

#### B. So arbeitet HaarVinci / Behandlungsablauf

Ergaenze einen visuellen Ablaufbereich mit 3 Schritten:

1. Beratung / Ausgangssituation
2. Einarbeitung / Methode
3. fertiges Ergebnis

Besonders geeignet:

- `02_reel_behandlung_und_ergebnis.mp4`

Dieser Bereich soll Vertrauen schaffen und den Ablauf verstaendlich machen.

#### C. Ueber Conny / Expertin

Ergaenze den Bereich „Ueber Conny“ oder einen angrenzenden Vertrauens-/Expertinnen-Bereich mit 1–2 echten Arbeitsbildern oder kurzen visuellen Ausschnitten von Conny.

Besonders geeignet:

- `04_reel_conny_produkterklaerung.mp4`

Ziel:

- Conny als echte Fachfrau zeigen
- persoenlichen und authentischen Eindruck verstaerken
- nicht nur Portraet, sondern auch Arbeitssituation zeigen

### 3. Vorerst keine direkte Reel-Einbettung

Bitte **keine Instagram-Reels direkt einbetten** und auch keine lauten, automatisch startenden Videos einbauen.

Falls sinnvoll, darfst du optional vorbereiten:

- kurze stumme Vorschau-Loops (spaeter aktivierbar)
- einheitliche Thumbnail-Bilder
- Play-Overlay fuer spaetere Versionen

Aber in der aktuellen Stufe gilt:

- Fokus auf Bilder / Standframes
- schnelle Ladezeit
- elegante, ruhige Wirkung

### 4. Designregeln

Wichtig:

- die Seite soll hochwertig, feminin, warm und editorial bleiben
- echte Medien sollen die Glaubwuerdigkeit erhoehen
- keine ueberladene Social-Media-Optik
- keine Instagram-Textwuesten oder hektischen Collagen

Die neuen Medien sollen sich harmonisch in das bestehende HaarVinci-Design einfuegen.

### 5. Technische Umsetzung

Bitte:

- geeignete Standbilder aus den Reels exportieren
- Bilder web-optimiert speichern
- saubere Dateibenennung verwenden
- responsive Darstellung beachten
- mobile Performance pruefen
- geaenderte/neu erstellte Medien im Projekt ordentlich ablegen

### 6. Erwartetes Ergebnis

Bitte liefere:

1. eine aktualisierte Website-Version
2. die ausgewaehlten/exportierten Bilder aus den Reels
3. eine kurze Notiz, welche Reels fuer welche Website-Bereiche verwendet wurden
4. eine Liste der geaenderten Dateien

## Prioritaet

Dies ist ein Zusatzauftrag auf Basis des bestehenden Homepage-Projekts.

Bitte keine komplette Neuentwicklung.
Das Ziel ist, mit den echten Medien von Conny die Homepage deutlich authentischer und staerker zu machen.
