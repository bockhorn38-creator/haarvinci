// Separate Offline-Ansicht für die private Abstimmung per Doppelklick.
// Der normale dist/-Build für HTTP/Webhosting wird dabei nicht verändert.
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = fileURLToPath(new URL('../', import.meta.url));
const dist = path.join(root, 'dist');
const target = path.join(root, 'offline-preview');
await fs.mkdir(target, { recursive: true });
const mime = {
  '.webp': 'image/webp',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.woff2': 'font/woff2',
  '.woff': 'font/woff',
  '.ttf': 'font/ttf',
};
const bufferCache = new Map();
async function dataURL(filename) {
  const file = path.resolve(filename);
  if (!file.startsWith(dist + path.sep)) throw new Error('Ungültiger Assetpfad');
  if (!bufferCache.has(file))
    bufferCache.set(
      file,
      `data:${mime[path.extname(file)] || 'application/octet-stream'};base64,${(await fs.readFile(file)).toString('base64')}`,
    );
  return bufferCache.get(file);
}
async function replaceAsync(text, regexp, callback) {
  const matches = [...text.matchAll(regexp)];
  const replacements = await Promise.all(matches.map(callback));
  for (let i = matches.length - 1; i >= 0; i--)
    text =
      text.slice(0, matches[i].index) +
      replacements[i] +
      text.slice(matches[i].index + matches[i][0].length);
  return text;
}
const routes = {
  '/': 'HaarVinci-Vorschau.html',
  '/impressum/': 'Impressum.html',
  '/datenschutz/': 'Datenschutz.html',
};
for (const [source, output] of [
  ['index.html', 'HaarVinci-Vorschau.html'],
  ['impressum/index.html', 'Impressum.html'],
  ['datenschutz/index.html', 'Datenschutz.html'],
  ['404.html', '404.html'],
]) {
  let html = await fs.readFile(path.join(dist, source), 'utf8');
  if (!html.includes('noindex, nofollow, noarchive'))
    throw new Error('Offline-Export ausschließlich aus einer internen Vorschau zulässig.');
  html = await replaceAsync(
    html,
    /<link[^>]*rel="stylesheet"[^>]*href="([^"]+)"[^>]*>/g,
    async (match) => {
      const file = path.join(dist, match[1].replace(/^\//, ''));
      let css = await fs.readFile(file, 'utf8');
      css = await replaceAsync(css, /url\(["']?([^)'"\s]+)["']?\)/g, async (url) => {
        if (url[1].startsWith('data:')) return url[0];
        const asset = url[1].startsWith('/')
          ? path.join(dist, url[1].slice(1))
          : path.resolve(path.dirname(file), url[1]);
        return `url("${await dataURL(asset)}")`;
      });
      return `<style>${css}</style>`;
    },
  );
  html = html.replace(/\s(?:srcset|sizes)="[^"]*"/g, '');
  html = await replaceAsync(
    html,
    /((?:src|data-full)=")\/(medien\/[^"\s]+)(")/g,
    async (match) => match[1] + (await dataURL(path.join(dist, match[2]))) + match[3],
  );
  html = await replaceAsync(
    html,
    /(<link[^>]*rel="(?:icon|apple-touch-icon)"[^>]*href=")([^"]+)(")/g,
    async (match) =>
      match[1] + (await dataURL(path.join(dist, match[2].replace(/^\//, '')))) + match[3],
  );
  html = await replaceAsync(
    html,
    /<script([^>]*?)src="\/([^"]+)"([^>]*)><\/script>/g,
    async (match) => {
      const js = await fs.readFile(path.join(dist, match[2]), 'utf8');
      if (/\bimport\s/.test(js))
        throw new Error('Ein externer Modulimport benötigt vor dem Offline-Export eine Bündelung.');
      return `<script type="module">${js}</script>`;
    },
  );
  html = html.replace(/href="(\/(?:#[^"]*)?|\/impressum\/|\/datenschutz\/)"/g, (_, href) => {
    if (href.startsWith('/#')) return `href="${routes['/']}${href.slice(1)}"`;
    return `href="${routes[href]}"`;
  });
  if (/\b(?:src|href)="\/(?:_astro|medien)/.test(html))
    throw new Error('Externe lokale Assets im Offline-Export übrig.');
  await fs.writeFile(path.join(target, output), html);
}
console.log(
  'Private Doppelklick-Vorschau mit eingebetteten Bildern, Schriften und Skripten erstellt.',
);
