// Optionaler, ausdrücklich angeforderter Standbildexport. Der normale Build
// benötigt nur die bereits exportierten PNGs, weder FFmpeg noch Originalvideos.
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { resolve, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = fileURLToPath(new URL('../', import.meta.url));
const directory = process.argv[2];
if (!directory) throw new Error('Aufruf: node scripts/export-reel-stills.mjs VIDEOORDNER');
const selected = JSON.parse(await readFile(join(root, 'assets-source/REEL-AUSWAHL.json'), 'utf8'));
const originFile = join(root, 'assets-source/HERKUNFT.json');
const origins = JSON.parse(await readFile(originFile, 'utf8'));
const sha256 = (data) => createHash('sha256').update(data).digest('hex');
const version = spawnSync('ffmpeg', ['-version'], { encoding: 'utf8' });
if (version.status !== 0) throw new Error('FFmpeg wird für den optionalen Export benötigt.');
await mkdir(join(root, 'assets-source'), { recursive: true });
for (const item of selected) {
  const video = resolve(directory, item.video);
  const videoHash = sha256(await readFile(video));
  const previous = origins[item.file];
  if (previous?.video_sha256 && previous.video_sha256 !== videoHash)
    throw new Error(`Originalvideo weicht vom geprüften Material ab: ${item.video}`);
  const output = join(root, 'assets-source', item.file);
  const result = spawnSync(
    'ffmpeg',
    [
      '-loglevel',
      'error',
      '-ss',
      String(item.seconds),
      '-i',
      video,
      '-frames:v',
      '1',
      '-map_metadata',
      '-1',
      '-y',
      output,
    ],
    { encoding: 'utf8' },
  );
  if (result.status !== 0) throw new Error(`Standbildexport fehlgeschlagen: ${result.stderr}`);
  origins[item.file] = {
    source: item.video,
    sha256: sha256(await readFile(output)),
    video_sha256: videoHash,
    frame_seconds: item.seconds,
    extraction: version.stdout.split('\n')[0],
    approval:
      'Vom Nutzer bereitgestelltes echtes Reel für den Homepage-Zusatzauftrag. Unretuschierter Standbildexport; Webausschnitt laut REEL-AUSWAHL.json.',
  };
}
await writeFile(originFile, JSON.stringify(origins, null, 2) + '\n');
console.log(
  `${selected.length} unveränderte Standbilder mit Video- und Bildprüfsummen exportiert.`,
);
