import sharp from 'sharp';
import fs from 'node:fs/promises';
import { createHash } from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = fileURLToPath(new URL('../', import.meta.url));
const sources = {
  schriftzug: 'logo-schwarz.png',
  'conny-sonnenlicht': 'conny-portraet.jpg',
  'conny-persoenlich': 'conny-persoenlich.jpg',
  'conny-gestaltungsentwurf': {
    file: 'conny-gestaltungsentwurf.png',
    // Nur der linke Bildbereich. Gesicht und Brille vollständig erhalten;
    // die eingebetteten Texte und das Logo rechts werden nicht dupliziert.
    crop: { left: 0, top: 0, width: 720, height: 1200 },
  },
  'studio-arbeitsplatz': 'studio-arbeitsplatz.jpg',
  'studio-uebersicht': 'studio-uebersicht.jpg',
  'studio-einblick': 'studio-einblick.jpg',
};
const reelStills = JSON.parse(
  await fs.readFile(path.join(root, 'assets-source/REEL-AUSWAHL.json'), 'utf8'),
);
for (const still of reelStills) {
  sources[still.key] = { file: still.file, ...(still.crop ? { crop: still.crop } : {}) };
}
const target = path.join(root, 'public/medien');
await fs.mkdir(target, { recursive: true });
const manifest = {};
for (const [key, entry] of Object.entries(sources)) {
  const filename = typeof entry === 'string' ? entry : entry.file;
  const crop = typeof entry === 'string' ? null : entry.crop;
  const source = await fs.readFile(path.join(root, 'assets-source', filename));
  const metadata = await sharp(source).metadata();
  const rotated = [5, 6, 7, 8].includes(metadata.orientation);
  const width = crop ? crop.width : rotated ? metadata.height : metadata.width;
  const height = crop ? crop.height : rotated ? metadata.width : metadata.height;
  const widths = [...new Set([360, 540, 690, 960, 1280, 1536].map((w) => Math.min(w, width)))].sort(
    (a, b) => a - b,
  );
  const variants = [];
  for (const size of widths) {
    const name = `${key}-${size}.webp`;
    // Sharp entfernt EXIF/XMP/GPS standardmäßig. Keine Retusche oder KI-Veränderung.
    const image = sharp(source).rotate();
    if (crop) image.extract(crop);
    await image
      .resize({ width: size, withoutEnlargement: true })
      .webp({ quality: 88, effort: 6 })
      .toFile(path.join(target, name));
    variants.push({ src: `/medien/${name}`, width: size });
  }
  manifest[key] = {
    width,
    height,
    src: variants.at(-1).src,
    srcset: variants.map((v) => `${v.src} ${v.width}w`).join(', '),
    source_sha256: createHash('sha256').update(source).digest('hex'),
    ...(crop ? { crop } : {}),
  };
}
await fs.writeFile(
  path.join(root, 'src/data/media.json'),
  JSON.stringify(manifest, null, 2) + '\n',
);
await fs.mkdir(path.join(root, 'public/lizenzen'), { recursive: true });
for (const [packageName, name] of [
  ['@fontsource-variable/manrope', 'Manrope-OFL.txt'],
  ['@fontsource/cormorant-garamond', 'Cormorant-Garamond-OFL.txt'],
]) {
  await fs.copyFile(
    path.join(root, 'node_modules', packageName, 'LICENSE'),
    path.join(root, 'public/lizenzen', name),
  );
}
console.log(
  `${Object.keys(sources).length} Motive aus unveränderten Originaldateien; responsive WebP-Auslieferung ohne private Metadaten bereit.`,
);

// Browser-/App-Icons aus dem gelieferten runden HaarVinci-Markenemblem.
const emblem = await fs.readFile(path.join(root, 'assets-source/markenemblem.png'));
for (const [size, filename] of [
  [32, 'favicon-32.png'],
  [48, 'favicon-48.png'],
  [180, 'apple-touch-icon.png'],
]) {
  await sharp(emblem)
    .resize(size, size)
    .png()
    .toFile(path.join(root, 'public', filename));
}
const icon = await sharp(emblem).resize(96, 96).png().toBuffer();
await fs.writeFile(
  path.join(root, 'public/favicon.svg'),
  `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 96 96"><image width="96" height="96" href="data:image/png;base64,${icon.toString('base64')}"/></svg>`,
);

// Technische Markengrafik: vorhandener Schriftzug, keine generierte Fotografie.
// 1200 x 630 ist für gängige Open-Graph-/WhatsApp-Vorschauen geeignet.
const background = Buffer.from(
  `<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="630"><rect width="1200" height="630" fill="#f7f4ee"/><rect x="36" y="36" width="1128" height="558" rx="12" fill="#fff" stroke="#d6bc8e" stroke-width="2"/><path d="M36 470h1128v112H36z" fill="#eee3df"/><path d="M94 106h90m832 418h90" stroke="#806038" stroke-width="3"/><path d="M600 495c0 18-9 27-27 27 18 0 27 9 27 27 0-18 9-27 27-27-18 0-27-9-27-27Z" fill="#806038"/></svg>`,
);
const logo = await sharp(path.join(root, 'assets-source/logo-schwarz.png'))
  .resize({ width: 900 })
  .png()
  .toBuffer();
await fs.mkdir(path.join(root, 'public/social'), { recursive: true });
await sharp(background)
  .composite([{ input: logo, left: 150, top: 135 }])
  .png()
  .toFile(path.join(root, 'public/social/haarvinci-vorschau-1.0.1.png'));
