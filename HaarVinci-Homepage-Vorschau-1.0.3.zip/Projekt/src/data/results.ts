import type media from './media.json';

export type Result = {
  id: string;
  title: string;
  image: keyof typeof media;
  alt: string;
  detail: string;
  description: string;
};

// Einzelne echte Ergebnisse aus dem autorisierten Reel-Material. Keine
// erfundenen Vorher-Nachher-Paare und keine aus Bildern abgeleiteten Mengen.
export const results: Result[] = [
  {
    id: 'rote-laengen',
    image: 'ergebnis-rot',
    title: 'Länge mit Ausdruck.',
    detail: 'ROTE LÄNGEN · GLATTES FINISH',
    alt: 'Rückenansicht langer roter Haare mit glattem Finish aus einem echten HaarVinci-Reel',
    description: 'Leuchtendes Rot und fließende Längen. Ein fertiger Look aus meinem Studio.',
  },
  {
    id: 'dunkler-glanz',
    image: 'ergebnis-glanz',
    title: 'Glanz bis in die Längen.',
    detail: 'DUNKLES HAAR · RUHIGER GLANZ',
    alt: 'Nahansicht glänzender dunkler Haare von hinten aus einem echten HaarVinci-Reel',
    description: 'Dunkle Nuancen und ein glänzendes Finish – hier in der Nahansicht.',
  },
];
