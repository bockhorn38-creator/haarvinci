export const site = {
  name: 'HaarVinci',
  title: 'HaarVinci | Schonende Haarverlängerung & Haarverdichtung in Kiel',
  description:
    'Mehr Länge und Fülle – mit deiner Haargesundheit im Mittelpunkt. Persönliche Weaving-Beratung, Haarverdichtung und transparente Preise bei Conny in Kiel.',
  origin: 'https://haarvinci.de',
  shareImage: '/social/haarvinci-vorschau-1.0.1.png',
  shareImageAlt:
    'HaarVinci-Logo in Creme, Rosé und Gold – Haarverlängerung und Haarverdichtung in Kiel',
  person: 'Conny',
  city: 'Kiel',
  address: 'Eichhofstraße 16, 24116 Kiel',
  phone: '0176 31600586',
  telephone: 'tel:+4917631600586',
  whatsapp: 'https://wa.me/4917631600586',
  email: 'info@haarvinci.de',
  instagram: 'https://www.instagram.com/haarvinci/',
  maps: 'https://maps.app.goo.gl/KvQ4o5tsqVvmvv2L7?g_st=awb',
  review: 'https://g.page/r/CWCMg9iC9hN9EBE/review',
};

export const weaving = [
  { name: '1 Reihe', price: '80 €' },
  { name: '2 Reihen insgesamt', price: '160 €' },
  { name: '3 Reihen insgesamt', price: '220 €' },
  { name: 'Jede weitere Reihe', price: '65 €' },
];
export const extras = [
  { name: 'Seitliche Zusatzintegration · 2 Elemente', price: '35 €' },
  { name: 'Vorbereitung & Anpassung eines neuen Haarsatzes', price: '40 €' },
];
export const removal = [
  { name: '1 Reihe entfernen', price: '20 €' },
  { name: '2 Reihen entfernen', price: '35 €' },
  { name: '3 Reihen entfernen', price: '45 €' },
];
export const modules = [
  { name: 'Form- und Spitzenanpassung', price: '20 €' },
  { name: 'Ponyschneiden', price: '15 €' },
  { name: 'Styling · Glätten oder Locken', price: '20 €' },
  { name: 'Sonderwünsche / Mehraufwand', price: 'nach Aufwand' },
];

// Bewusst ohne bisherige, noch abzugleichende Detailbehauptungen zu Erfahrung,
// Beratungsdauer und Lieferwochen. Keine medizinische Diagnose oder Zusage.
export const faqs = [
  {
    q: 'Was ist dir bei einer Haarverlängerung besonders wichtig?',
    a: 'Die Gesundheit und der Erhalt deines Eigenhaars stehen an erster Stelle. Deshalb stimme ich Haarmenge, Reihenanzahl und Verteilung individuell auf dein Haar ab. Welche Lösung sinnvoll ist, besprechen wir persönlich.',
  },
  {
    q: 'Wie funktioniert deine Weaving-Methode?',
    a: 'Ich flechte aus deinem Eigenhaar eine Cornrow-Basis und nähe die Tressen daran an. Die Befestigung erfolgt ohne Kleber, Hitze oder Chemie. Das beschreibt die Befestigung, nicht die Behandlung des Haarmaterials oder sämtliche Pflegeprodukte.',
  },
  {
    q: 'Werden dabei Mikroringe verwendet?',
    a: 'Je nach Absprache kann jeweils ein kleiner Mikroring das Ende eines Cornrows sichern – ungefähr vier pro Reihe, abhängig von der Ausführung. Alternativ vernähe ich die Enden. Die Tressen selbst werden auf die geflochtene Basis genäht.',
  },
  {
    q: 'Ist die Erstberatung kostenlos?',
    a: 'Ja, die Erstberatung ist kostenlos. Wir sprechen über deine Wünsche und sehen uns dein Eigenhaar und deine Möglichkeiten an. Die Beratung ersetzt keine medizinische Diagnose.',
  },
  {
    q: 'Wie bereite ich mich auf die Beratung vor?',
    a: 'Komm möglichst mit frisch gewaschenen, ungestylten und luftgetrockneten Haaren. Wenn du vorher färben lassen möchtest, plane den Friseurtermin möglichst ein bis zwei Wochen vor der Beratung. Danach sollten deine Haare bereits gewaschen worden sein: Direkt nach einer Färbung kann der Farbton noch dunkler wirken.',
  },
  {
    q: 'Wie viele Reihen brauche ich?',
    a: 'Das hängt von deinem Eigenhaar und der Haarmenge ab. 100 g werden häufig auf zwei Reihen verteilt. Bei feinem oder weniger Eigenhaar können mehr Reihen sinnvoll sein, um die Belastung besser zu verteilen. Deshalb ergibt sich die Reihenanzahl nicht allein aus dem Haargewicht.',
  },
  {
    q: 'Wann müssen die Haare hochgesetzt werden?',
    a: 'Üblicherweise nach sechs bis zwölf Wochen, je nach Eigenhaar und Ausgangslage. Dabei entferne ich die vorhandene Einarbeitung, kämme das Eigenhaar aus, baue die Basis neu auf und arbeite die Tressen wieder ein.',
  },
  {
    q: 'Wie lange halten die Haare?',
    a: 'Bei entsprechender Pflege können die Haare bis zu einem Jahr halten. Wenn für die ausgewählten Haare etwas anderes gilt, besprechen wir das persönlich. Das ist keine garantierte Mindesthaltbarkeit und auch nicht der Abstand bis zum nächsten Hochsetzen.',
  },
  {
    q: 'Wie bürste ich die Haare richtig?',
    a: 'Beginne bei den Spitzen und bürste vorsichtig nach unten. Arbeite dich abschnittsweise höher, bis das Haar entwirrt ist. Halte dabei am Ansatz gegen oder lege die Hand an den Kopf, damit möglichst wenig Zug entsteht. Nicht vom Ansatz durch Knoten reißen.',
  },
  {
    q: 'Was ist nach Haarwäsche und Sport wichtig?',
    a: 'Nimm die Haare zum Sport passend zusammen. Verwende nach jeder Shampoo-Wäsche einen Conditioner in den Längen. Föhne die Haare möglichst trocken; mindestens Kopfhaut, Ansätze und Cornrows sollen gut durchtrocknen.',
  },
  {
    q: 'Wann verwende ich Serum oder Haaröl?',
    a: 'Ich empfehle ein geeignetes Serum oder Haaröl sparsam in den noch handtuchtrockenen Längen und Spitzen. Das ist meine bevorzugte Pflegeroutine; die Anwendung kann je nach Produkt und individuellem Haar unterschiedlich sein.',
  },
  {
    q: 'Darf ich mit nassen Haaren schlafen?',
    a: 'Gehe erst schlafen, wenn auch die Längen trocken sind. Feuchte Haare können durch nächtliche Reibung geschädigt werden und verfilzen. Schlecht durchtrocknende Bereiche können außerdem muffig riechen. Handtuchtrockene Längen beziehen sich nur auf den Pflegeschritt nach dem Waschen.',
  },
  {
    q: 'Kann ich Extensions aus einem anderen Studio mitbringen?',
    a: 'Grundsätzlich ja. Ich schaue mir Haar und Einarbeitung zunächst persönlich an und arbeite geeignete Tressen nach meiner eigenen Weaving-Methode neu ein. Für fremdes Haar gebe ich keine Qualitäts- oder Haltbarkeitsversprechen. Eignung und Aufwand klären wir vorab.',
  },
  {
    q: 'Entfernst du Bondings oder andere Fremdarbeiten?',
    a: 'Das beurteile ich individuell nach Aufwand. Bitte beschreibe bei deiner Anfrage, welche Methode du trägst und was entfernt werden soll. Tapes und Bondings biete ich nicht als Einarbeitungsmethode an.',
  },
  {
    q: 'Welche Lösung passt zu dünnem Haar oder zum Oberkopf?',
    a: 'Je nach Ausgangslage kommen eine Haarverdichtung oder eine individuelle Oberkopflösung, beispielsweise ein Topper, infrage. Entscheidend ist, was dein Eigenhaar sinnvoll tragen kann. Eine verbindliche Eignung lässt sich nicht allein aus einer Nachricht oder einem Foto zusagen.',
  },
  {
    q: 'Wie laufen Bestellung, Termin und Bezahlung ab?',
    a: 'Wir wählen in der Beratung Haar und Leistungen aus. Der vollständige Preis für das Haarmaterial wird separat vorab bezahlt; anschließend wird bestellt und der Einarbeitungstermin verbindlich vereinbart. Die aktuelle Lieferzeit berücksichtigen wir gemeinsam bei der Planung. Die Dienstleistung wird separat am Termin berechnet.',
  },
  {
    q: 'Was kostet meine Behandlung?',
    a: 'Die Reihenpreise und das Neuset-Beispiel geben dir Orientierung. Dein persönlicher Gesamtpreis hängt von Haarlänge, Haarmenge, Haarauswahl, Reihenanzahl und vereinbarten Zusatzleistungen ab. Ein verbindliches Angebot erstelle ich nach der Beratung.',
  },
  {
    q: 'Was ist für meine erste Anfrage hilfreich?',
    a: 'Beschreibe deinen Wunsch – Länge, Fülle oder Oberkopf –, deine ungefähre Eigenhaarlänge, vorhandene Extensions samt Methode und mögliche Terminzeiten. Fotos kannst du nach Absprache freiwillig direkt an mich schicken. Eine Anfrage ist noch keine Terminbestätigung.',
  },
  {
    q: 'Was mache ich bei Beschwerden oder starkem Zug?',
    a: 'Bitte wende dich persönlich an mich, damit wir die Einarbeitung und deinen Haarzustand besprechen können. Eine Nachricht ersetzt keine persönliche Beurteilung. Bei Beschwerden gebe ich keine pauschale Entwarnung oder medizinische Diagnose.',
  },
];
