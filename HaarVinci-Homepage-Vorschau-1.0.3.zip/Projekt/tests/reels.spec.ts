import { test, expect } from '@playwright/test';
import sharp from 'sharp';

const reelImages = '.result-card > img, .treatment-grid img, .conny-work > img';

test('echte Ergebnisse und Behandlungsbilder funktionieren auch auf kleinen und mittleren Ansichten', async ({
  page,
}) => {
  for (const width of [320, 700, 1100]) {
    await page.setViewportSize({ width, height: 850 });
    await page.goto('/');
    await page.getByRole('link', { name: 'Ergebnisse ansehen', exact: true }).click();
    await expect(page).toHaveURL(/#ergebnisse$/);
    await expect(page.locator('#ergebnisse h2')).toBeInViewport();
    await expect(page.locator('.result-card')).toHaveCount(2);
    await expect(page.locator('.treatment-grid > li')).toHaveCount(3);
    await expect(page.locator('.journey > li')).toHaveCount(5);
    for (const img of await page.locator(reelImages).all()) {
      await img.scrollIntoViewIfNeeded();
      await expect(img).toHaveJSProperty('complete', true);
      expect(await img.evaluate((e: HTMLImageElement) => e.naturalWidth)).toBeGreaterThan(0);
      const box = await img.boundingBox();
      expect(box!.x).toBeGreaterThanOrEqual(0);
      expect(box!.x + box!.width).toBeLessThanOrEqual(width + 1);
    }
    expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBeLessThanOrEqual(
      width,
    );
  }
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto('/');
  for (const id of ['methode', 'ergebnisse', 'conny']) {
    await page.locator(`#${id}`).scrollIntoViewIfNeeded();
    await page.locator(`#${id}`).screenshot({ path: `test-results/reels-${id}-mobil.png` });
  }
});

test('mobile Reel-Standbilder bleiben klein und enthalten keine privaten Bildmetadaten', async ({
  page,
  request,
}) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto('/');
  const images = page.locator(reelImages);
  await expect(images).toHaveCount(6);
  let totalBytes = 0;
  for (const img of await images.all()) {
    await img.scrollIntoViewIfNeeded();
    await expect(img).toHaveJSProperty('complete', true);
    await expect(img).toHaveAttribute('loading', 'lazy');
    const src = await img.evaluate((e: HTMLImageElement) => e.currentSrc);
    const response = await request.get(src);
    expect(response.ok()).toBe(true);
    const bytes = await response.body();
    expect(bytes.length).toBeLessThan(150_000);
    totalBytes += bytes.length;
    const metadata = await sharp(bytes).metadata();
    expect(metadata.format).toBe('webp');
    expect(metadata.width).toBeLessThanOrEqual(720);
    expect(metadata.exif).toBeUndefined();
    expect(metadata.xmp).toBeUndefined();
  }
  expect(totalBytes).toBeLessThan(600_000);
  test.info().annotations.push({ type: 'mobile-reel-bytes', description: String(totalBytes) });
});

test('Standbilder brauchen kein JavaScript, keine Videoeinbettung und keine erfundenen Vergleiche', async ({
  browser,
}) => {
  const context = await browser.newContext({
    javaScriptEnabled: false,
    viewport: { width: 390, height: 844 },
  });
  const page = await context.newPage();
  await page.goto('http://127.0.0.1:4322/');
  await expect(page.locator('.result-card')).toHaveCount(2);
  await expect(page.locator('.conny-work')).toContainText('beim Finish');
  await expect(page.locator('.treatment-story')).toContainText(
    'bisherigen Extensions sind entfernt',
  );
  await expect(page.locator('iframe, video, audio, .before-after')).toHaveCount(0);
  expect(await page.content()).not.toMatch(/\.mp4|instagram\.com\/embed/);
  await expect(page.locator('#conny .approved-portrait')).toBeAttached();
  await context.close();
});
