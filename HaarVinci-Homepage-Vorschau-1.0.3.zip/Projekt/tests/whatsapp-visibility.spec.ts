import { test, expect } from '@playwright/test';
import { resolve } from 'node:path';

for (const width of [320, 390, 412, 760, 1100, 1440]) {
  test(`WhatsApp ist sofort und beim Scrollen erreichbar bei ${width}px`, async ({ page }) => {
    await page.setViewportSize({ width, height: 800 });
    await page.emulateMedia({ reducedMotion: 'reduce' });
    await page.goto('/');
    const link = page.locator('.header-whatsapp');
    await expect(link).toBeVisible();
    await expect(link).toBeInViewport({ ratio: 1 });
    await expect(link).toHaveAccessibleName('Conny per WhatsApp kontaktieren');
    await expect(link).toHaveAttribute('href', 'https://wa.me/4917631600586');
    await expect(link).toHaveAttribute('rel', 'noopener noreferrer');
    const rect = (await link.boundingBox())!;
    expect(rect.height).toBeGreaterThanOrEqual(48);
    expect(rect.width).toBeGreaterThanOrEqual(48);
    for (const id of ['methode', 'ergebnisse', 'preise', 'conny', 'kontakt']) {
      await page.locator(`#${id}`).scrollIntoViewIfNeeded();
      await expect(link).toBeInViewport({ ratio: 1 });
      expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBeLessThanOrEqual(
        width,
      );
      const button = (await link.boundingBox())!;
      const header = (await page.locator('.site-header').boundingBox())!;
      expect(button.y).toBeGreaterThanOrEqual(header.y);
      expect(button.y + button.height).toBeLessThanOrEqual(header.y + header.height);
    }
    await link.focus();
    await expect(link).toBeFocused();
    await link.evaluate((anchor) =>
      anchor.addEventListener('click', (event) => {
        event.preventDefault();
        document.documentElement.dataset.whatsappTarget = (anchor as HTMLAnchorElement).href;
      }),
    );
    await link.click();
    await expect(page.locator('html')).toHaveAttribute(
      'data-whatsapp-target',
      'https://wa.me/4917631600586',
    );
    if ([412, 1440].includes(width)) {
      await page.goto('/');
      await page.screenshot({ path: `test-results/whatsapp-kopfzeile-${width}.png` });
    }
  });
}

test('WhatsApp bleibt ohne JavaScript auf Smartphone und PC sichtbar', async ({ browser }) => {
  const context = await browser.newContext({ javaScriptEnabled: false });
  const page = await context.newPage();
  for (const width of [320, 1440]) {
    await page.setViewportSize({ width, height: 850 });
    await page.goto('http://127.0.0.1:4322/');
    await expect(page.locator('.header-whatsapp')).toBeInViewport({ ratio: 1 });
    await expect(page.locator('.header-whatsapp')).toHaveAttribute(
      'href',
      'https://wa.me/4917631600586',
    );
  }
  await context.close();
});

test('WhatsApp ist auch in den eingebetteten Vorschauseiten sofort sichtbar', async ({
  page,
  context,
}) => {
  await context.setOffline(true);
  await context.route('http://127.0.0.1:4322/offline/*.html', async (route) => {
    const name = new URL(route.request().url()).pathname.split('/').at(-1)!;
    if (
      !['HaarVinci-Vorschau.html', 'Impressum.html', 'Datenschutz.html', '404.html'].includes(name)
    )
      throw new Error('Unbekannte Seite');
    await route.fulfill({ path: resolve('offline-preview', name), contentType: 'text/html' });
  });
  for (const width of [320, 1440]) {
    await page.setViewportSize({ width, height: 850 });
    for (const name of [
      'HaarVinci-Vorschau.html',
      'Impressum.html',
      'Datenschutz.html',
      '404.html',
    ]) {
      await page.goto(`/offline/${name}`);
      const link = page.locator('.header-whatsapp');
      await expect(link).toBeVisible();
      await expect(link).toBeInViewport({ ratio: 1 });
      await expect(link).toHaveAttribute('href', 'https://wa.me/4917631600586');
    }
  }
});
