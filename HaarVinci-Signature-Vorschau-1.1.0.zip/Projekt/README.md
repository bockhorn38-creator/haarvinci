# HaarVinci Signature · Vorschau 1.1.0

Weiterentwicklung der bestehenden Astro-Website 1.0.3. Elfenbein, Tiefschwarz, Soft Rosé und sparsame Champagnergold-Akzente; grüne WhatsApp-Kontakte. Kein Neubau und kein Livegang.

**Offener Lieferpunkt:** Das neue ZIP mit den acht zugeschnittenen Vorher-Nachher-JPGs liegt im Workspace noch nicht vor. Die neun Textdateien sind eingelesen und anhand der mitgelieferten Prüfsummen geprüft; die im Chat sichtbaren Bildvorschauen wurden zur Einordnung betrachtet. Die vier neuen Paare sind deshalb noch nicht mit den echten Dateien integriert und visuell abgenommen. Es wurden keine Ersatz-Kundinnenbilder erzeugt. Die derzeit teilbare Vorschau zeigt die bereits in 1.0.3 verwendeten Reel-Standbilder. Der getrennte private Galeriepfad ist mit ausdrücklich fiktiven Testflächen geprüft.

## Ansehen und starten

Die einzelne Datei `HaarVinci-fuer-Conny.html` enthält Bilder, Schriften und Lizenztexte. Nach dem Herunterladen im Browser öffnen. Zum Weitergeben in WhatsApp als Dokument anhängen. Auf GitHub den Download-Pfeil verwenden; der Raw-Endpunkt kann HTML als Quelltext anzeigen. WhatsApp stellt die Datei nicht selbst als Website dar.

Das Vorschau-ZIP vollständig entpacken und `HaarVinci-Vorschau.html` öffnen. `Impressum.html` und `Datenschutz.html` daneben lassen. Das ZIP enthält außerdem die einzelne Conny-Datei, Quellen, Prüfbericht und Bildschirmansichten.

Für die Entwicklung mit Node.js 24 LTS im Ordner `website` beziehungsweise `Projekt`:

```bash
npm ci
npm run dev
```

`http://localhost:4321` öffnen. Für einen statischen Build: `npm run build`, `npm run export:preview`, `npm run preview -- --port 4321 --ignore-lock`. Der normale Hostingbuild steht unter `dist/`, die eingebetteten Dateien unter `offline-preview/`. Kein Backend und keine Datenbank nötig. Telemetrie wird durch den vorhandenen Wrapper deaktiviert.

## Neue Galerie ausschließlich privat vorbereiten

Nach Lieferung und sicherem Entpacken des Übergabe-ZIPs:

```bash
npm run import:signature -- PFAD_ZUM_UEBERGABEORDNER
npm run build:private
```

Der Import prüft alle acht JPGs gegen die mitgelieferten SHA-256-Werte, bevor er Dateien übernimmt. Originale landen ausschließlich in `.private-media/signature-1.1/`, getrennte Builds unter `.private-preview/dist/` und die private Einzeldatei unter `.private-preview/offline/HaarVinci-fuer-Conny.html`. Diese Ordner sowie `handoff/` und hineingelegte ZIP-Dateien sind von Git ausgeschlossen. Private Bilder gehören nicht in reguläre Pakete. Die neue Galerie zeigt Vorher/Nachher gleichzeitig mit unverändertem Seitenverhältnis, sachlichen Beschriftungen und einem internen Hinweis zur Paar- und Rechteprüfung. Kein Schieberegler, der unterschiedliche Blickwinkel irreführend überlagert.

**Private Dateien mit ungeklärten Kundinnenfotos nicht in das öffentliche Repository, öffentliche Downloads oder Webhosting übernehmen.** In `content/paired-results.json` bleiben `websiteApproved` und `pairConfirmed` für alle vier Fälle `false`. Ein globaler Freigabeschalter ersetzt diese Einzelfreigaben nicht. Der normale Build bindet diese Bilder nicht ein. Für einen späteren tatsächlich freigegebenen Einsatz sind Rechte, Bildzuordnung und Originaldateien unter `assets-source/approved-results/` ausdrücklich abzugleichen; keine automatische Freigabe durch den Import.

## Was umgesetzt ist

- Neue Bildinszenierung im Hero mit vorhandener echter HaarVinci-Arbeit; Ergebnisse früh in der Seite, anschließend dunkler Vertrauensbereich. Originalporträt von Conny mit echten HTML-Texten im Über-Conny-Bereich. Der bestätigte KI-Gestaltungsentwurf bleibt als Quelle erhalten und wird nicht als reale Szene ausgegeben.
- Google-Unternehmensprofil neutral als „HaarVinci auf Google“, getrennt vom bestätigten „Bewertung abgeben“-Link. Redaktioneller Presseverweis zu den Kieler Nachrichten. Keine erfundenen Sterne, Zitate, Kundennamen oder medizinischen Versprechen, keine fremden Screenshots.
- Gut sichtbarer grüner WhatsApp-Kontakt in der angehefteten Kopfzeile ohne JavaScript und ohne zweite Ebene über Texten oder Formularen. Unter 375 Pixeln kompakt als zugängliches Symbol, darüber beschriftet. Beratung und Parkplatzinfo werden erst durch bewusstes Anklicken geöffnet.
- Anfahrt: Eichhofstraße 16, 24116 Kiel, 1. Obergeschoss eines Wohngebäudes; nicht der Imbiss im Erdgeschoss. Separater Kundenstellplatz am Eichkamp nach Absprache. Studio-Route über den bestätigten Link, Parkplatzdetails per vorbereiteter WhatsApp-Anfrage. Kein erfundener zweiter Karten-Pin und keine konkrete unbekannte Stellplatzroute.
- Neun FAQ zuerst, zehn weitere nativ aufklappbar. Sämtliche bisherigen Fach-, Pflege-, Preis-, Formular- und Studio-Galeriefunktionen bleiben erhalten. Die fünf Beratungs-/Bestellschritte und vollständige Material-Vorauszahlung sind unverändert.

## Prüfen

```bash
npm run check
npm run format:check
npm run build
npm run export:preview
npm test
```

Chromium/Playwright, standardmäßig `/usr/bin/chromium`. Andernorts nach `npx playwright install chromium` die Variable `CHROMIUM_PATH=playwright` verwenden. Alle Eingaben sind fiktiv; WhatsApp-/E-Mail-Aktionen werden abgefangen, keine Nachrichten versendet. Details, Grenzen und Ergebnisse: [PRUEFUNG.md](PRUEFUNG.md). Änderungen und Medienstatus: [AENDERUNGEN-1.1.0.md](AENDERUNGEN-1.1.0.md).

## Freigaben und offene Punkte

`content/release.json` bleibt vollständig auf `false`. `npm run build:release` bricht ohne vollständige Freigaben und Rechtstexte ab. Private Bildvorschau und öffentlicher Release sind technisch gegenseitig ausgeschlossen. `noindex` ist kein Zugriffsschutz; private Kundinnenfotos werden deshalb gar nicht in reguläre Auslieferungen geschrieben.

Offen sind das neue Original-ZIP, die acht individuellen Website-Freigaben, Bestätigung der Bildpaarungen (besonders Goldblond/„Ohne extensions“), vollständige Rechtstexte, finaler Hauseingang/Klingelschild sowie genaue Parkplatzzufahrt, Stellplatznummer und Zugangsweg. Google-Maps-, Bewertungs- und Presse-Screenshots bleiben reine Referenzen. Kein IONOS-Upload, keine Domain-, DNS-, Mail- oder Vertragsänderung. Android-, Windows- und Django-App bleiben unberührt.

Die Cloud sperrt direkte `file://`-Navigation. Die tatsächlichen eingebetteten Dateien werden über erlaubtes lokales HTTP ohne weitere Netzabrufe geprüft. Doppelklick, Android-Dateizuordnung und die tatsächliche WhatsApp-Übertragung müssen auf dem privaten Gerät geprüft werden.
