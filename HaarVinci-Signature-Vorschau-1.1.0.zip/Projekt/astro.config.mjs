import { defineConfig } from 'astro/config';
import { fileURLToPath } from 'node:url';

const privatePreview = process.env.HAARVINCI_PRIVATE_PREVIEW === 'true';
const privateRoot = fileURLToPath(new URL('./.private-preview/', import.meta.url));

// Statische Dateien für reguläres Webhosting; keine Server-/Cloud-Adapter.
export default defineConfig({
  ...(privatePreview ? { outDir: './.private-preview/dist/' } : {}),
  site: 'https://haarvinci.de',
  output: 'static',
  trailingSlash: 'always',
  build: { format: 'directory' },
  vite: { build: { sourcemap: false } },
  integrations: [
    {
      name: 'haarvinci-private-preview-boundary',
      hooks: {
        'astro:config:done': ({ config }) => {
          if (privatePreview && !fileURLToPath(config.outDir).startsWith(privateRoot))
            throw new Error(
              'Private Galerie darf nur in den getrennten Ordner .private-preview/ ausgegeben werden.',
            );
        },
      },
    },
  ],
});
