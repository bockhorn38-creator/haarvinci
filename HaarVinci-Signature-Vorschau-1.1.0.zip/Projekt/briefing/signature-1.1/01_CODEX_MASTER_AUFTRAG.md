# HAARVINCI – CODEX MASTER-AUFTRAG
## Design-Upgrade 1.1 mit echten Vorher-Nachher-Bildern, Vertrauenselementen sowie Anfahrt und Kundenparkplatz

**Stand:** 12. November 2026  
**Ausgangsbasis:** bereits funktionsfähige HaarVinci-Homepage Version 1.0.3 (Astro), keinesfalls ein Neubau.  
**Aufgabe:** vorhandene Seite visuell deutlich aufwerten, neue Medien kontrolliert integrieren und Alltagsproblem Anfahrt/Parken lösen.  
**Ergebnis:** neue lokal testbare Version 1.1 mit separater mobiler HTML-Vorschau, Tests und einem Änderungsprotokoll. Noch kein Livegang.

## A. Vor dem Programmieren

1. Vorhandenes Astro-Projekt einschließlich `AGENTS.md`, `src/pages/index.astro`, `src/styles/global.css`, `src/data/site.ts`, `src/data/results.ts`, `src/components/FloatingWhatsApp.astro`, `src/data/publication.ts`, `content/release.json`, Medienpipeline und Tests lesen.
2. Das beigelegte Briefing `HaarVinci_Website_Briefing_Timo.md` ist die **maßgebliche fachliche Grundlage**. Die aktuellen Angaben von Conny haben Vorrang vor der möglicherweise veralteten, momentan live geschalteten Website.
3. Vorhandene funktionierende Features und Barrieren gegen versehentlichen Livegang **beibehalten**. Insbesondere `content/release.json` nicht auf `true` setzen, keine Rechtstexte erfinden und keine personenbezogenen App-Daten übernehmen.
4. Bestehende Android-App, Git-Branches anderer Projekte, IONOS-Website, Mail Business und DNS nicht verändern. Vor Start einen Git-Checkpoint anlegen (sofern Git eingerichtet ist).
5. Medien dieses Pakets systematisch importieren; die Quellbilder und referenzierten WhatsApp-Screenshots nicht durch KI erzeugen oder retuschieren.

## B. Neues Design: „HaarVinci Signature“

Es soll professionell und luxuriös wirken, dabei dem **tatsächlich hellen Studio** entsprechen: vorwiegend warmes Elfenbein und angenehme Flächen; Schwarz als bewusster Kontrast; Champagnergold nur gezielt. Kein überladenes Luxusklischee und keine aggressive Metallic-Optik.

**Farbsystem:**
- Elfenbein / Seitenbasis: `#F8F4ED`
- Warmes Tiefschwarz / Text, dunkle Sektionen: `#211D1C`
- Champagnergold / Linien, Akzente: `#B99A68`
- Soft Rosé / einzelne ruhige Flächen: `#E7D4D0`
- Warmgrau / Sekundärtexte: `#6C625D`
- WhatsApp-Kontakt: bekannter grüner Akzent; mit gutem Textkontrast.

**Typografie und Stil:** großzügige elegante Serif-Überschriften und schlichte Sans-Serif-Fließtexte, gute Lesbarkeit auf dem Smartphone, klare optische Hierarchie, wenig dekorative Elemente, großzügige Abstände. Nutzerinnen sollen sich auf Haare, Ergebnisse und Conny konzentrieren.

**Hero:** großzügiges echtes Motiv, prägnante Botschaft, sofort sichtbarer Beratungs-CTA. Ein alternativer Hero kann für die interne Vorschau mit einem neuen Kundenfoto getestet werden; die öffentliche Verwendung ist an Fotofreigabe gebunden. Das mehrfach bestätigte Conny-Porträt ist für „Über Conny“ vorgesehen.

**Sektionen:**
1. Titelbereich: HaarVinci, „Mehr Länge und Fülle – mit deiner Haargesundheit im Mittelpunkt“, direkt sichtbare Kontaktmöglichkeit.
2. **Echte Ergebnisse** möglichst früh, mit 3–4 freigegebenen Vorher-Nachher-Paaren.
3. Vertrauensbereich: echte Google-Bewertungen **nur als Link oder mit gesondert zulässig nutzbaren Zitaten**, außerdem Presseerwähnung mit Link zur Originalquelle.
4. Leistungen: Mehr Länge, Mehr Fülle, Oberkopflösungen.
5. Weaving-Methode und individueller Beratungs- und Bestellablauf. Fachlich beim Briefing bleiben: Cornrow-Basis, angenähte Tressen, optionale Mikroringe am Cornrow-Ende, keine Garantien.
6. Über Conny und echtes helles Studio, ohne künstlich erzeugte Geschäftsräume als reale Aufnahmen auszugeben.
7. Transparente Preise, FAQ verdichten (zunächst 8–10 wichtige Fragen, übrige aufklappbar / sinnvoll gruppiert), Kontakt.
8. **„Anfahrt & Parken“** als deutlich erkennbarer praktischer Abschnitt vor dem Footer oder im Kontaktbereich.

Das vorhandene Basis-Design nicht nur minimal umfärben: Bildinszenierung, Abstände, Section-Rhythmus, CTA-Hierarchie und mobile Lesbarkeit werden gezielt neu gestaltet. Nicht die gesamte Website neu programmieren.

## C. Echte Vorher-Nachher-Galerie

Im Paket: `02_Neue_Ergebnisse/Bereit_zur_Pruefung/` – die aus den WhatsApp-Screenshots **lediglich zugeschnittenen** Bilder. Quell-Screenshots im Schwesterordner. Keine Retusche von Haar, Länge, Glanz oder Dichte; lediglich Layoutzuschnitt, Web-Kompression, responsive Größen und Metadatenbereinigung erlauben.

**Vier zugeordnete Paare, Reihenfolge geprüft:**
- `01_aschblond_vorher.jpg` + `01_aschblond_nachher.jpg` (Originale 1960/1961)
- `02_rotbraun_vorher.jpg` + `02_rotbraun_nachher.jpg` (1962/1963)
- `03_braun_weihnacht_vorher.jpg` + `03_braun_weihnacht_nachher.jpg` (1964/1965)
- `04_goldblond_vorher.jpg` + `04_goldblond_nachher.jpg` (1966/1967)

**Umsetzung:**
- Große, ruhige Galerie-Karten. Vorher und Nachher sollen gleichzeitig, beschriftet und im passenden Seitenverhältnis erkennbar sein.
- Optional zugänglichen Bildvergleich per Schieberegler nur dort einbauen, wo Blickwinkel und Bildausschnitt hinreichend vergleichbar sind. Sonst **Side-by-Side** bevorzugen, um nicht irreführend zu wirken.
- Kein Erfinden von Grammzahlen, Haarherkunft, Preis, Behandlungstechnik oder garantierten Ergebnissen pro Fall. Bildtitel neutral halten.
- Responsiv: 360–430 px besonders sorgfältig. Bilder nicht übermäßig beschneiden; Haare in voller Länge möglichst sichtbar lassen.
- **Wichtig für Veröffentlichung:** Kunde/Kundin muss für Website-Nutzung freigegeben haben. Status ist aktuell **offen**, daher in interner Vorschau zeigen, Freigabe-Gate beibehalten und vor öffentlichem Release nur eindeutig freigegebene Bilder ausliefern.
- Für Copyright und Datenschutz nicht blind Instagram/WhatsApp-Bilder auf öffentlich zugängliche URL hochladen.

## D. Portrait, Studio, Fotos

- `03_Studio_und_Conny/`: echte Studio-Aufnahmen und mehrere Conny-Motive.
- `Conny_Gestaltungsentwurf_bereits_bestaetigt.png` zeigt eine von Nutzer bevorzugte gestalterische Fassung. Nicht als Beleg für eine reale Szene darstellen; vorhandene Texte im Bild nicht durch Textlagen doppeln. Möglichst das echte zugrunde liegende Porträt mit **echtem HTML-Text** elegant kombinieren.
- `04_Logos/`: schwarzer Schriftzug primär im hellen Header; goldene Variante oder Kreis-Emblem punktuell, sparsam. Mobile Lesbarkeit und saubere Transparenzen prüfen.
- Bestehende Reel-Still-Bilder aus Version 1.0.3 nicht löschen, nur sinnvoll mit neuen Ergebnissen kombinieren. Keine automatisch abgespielten fremden Instagram-Einbettungen.

## E. Anfahrt: Alltagsproblem tatsächlich lösen

**Gesicherte Informationen vom Auftraggeber:**
- HaarVinci ist in **Eichhofstraße 16, 24116 Kiel, im 1. Obergeschoss eines Wohngebäudes**.
- Das Studio ist **kein Ladenlokal im Erdgeschoss**. Kundinnen landen gelegentlich versehentlich beim Imbiss unten. Den aktuellen Namen des Imbisses nicht erfinden.
- Conny hat seit **Oktober 2026 einen eigenen Kundenparkplatz am Eichkamp** angemietet. Die exakte Stellplatznummer, die private Zufahrt und der Hauseingang sind noch nicht bestätigt.

**UI-Bereich „So findest du mich“:**
- Zweiteilige, gut sichtbare Anfahrtskarte: links „Zum Studio“ mit klarer Adresse und Hinweis „1. Obergeschoss – nicht der Imbiss im Erdgeschoss“; rechts „Parken am Eichkamp“ mit Hinweis „Kundenstellplatz nach Absprache; genaue Zufahrt und Stellplatzinformation erhältst du bei Terminvereinbarung“.
- Richtiger Link zum Studio: `https://maps.app.goo.gl/KvQ4o5tsqVvmvv2L7?g_st=awb` (bereits im Conny-Briefing). Falls unzuverlässig, gleichwertiger korrekt adressierter externer Navigationslink.
- Für den Parkplatz **KEIN frei erfundener zweiter Ziel-Pin, kein unbestätigter Routen-Link zu einem konkreten Parkplatz**, keine verlässliche Nutzungszusage für mehrere Fahrzeuge.
- Stattdessen Button „Parkplatzinfo per WhatsApp anfragen“, der eine höfliche Nachricht über den bereits vorhandenen WhatsApp-Link vorbereitet. Genaue Daten nach Bestätigung durch Conny nachrüsten.
- Zwei beigefügte Google-Maps-Screenshots 1970 und 1971 ausschließlich als **interne Referenz**. Diese nicht als Website-Karte veröffentlichen, nicht als eigene Kartengrafik ausgeben, keine unbelegte Umzeichnung exakter Stellflächen.
- Keine ungeprüfte Google-Maps-Einbettung/Tracker. Externe Navigation ist die datensparsame erste Lösung. Wenn später Karten-Embed gewünscht, Privatsphäre, Einwilligung und Lizenzbedingungen vorher prüfen.
- Auf Mobilgeräten Adresse mit zwei eindeutig erkennbaren Aktionen anzeigen: „Route zum Studio“ und „Parkplatzinfo anfragen“.

## F. Google-Rezensionen und Presse – professionell, sauber

- `06_Bewertungen_und_Presse_NUR_Referenz/`: Google-Review-Screenshots und Ausschnitte zur Berichterstattung. **Nicht als Bildmaterial direkt auf der Website verwenden.** Besonders keinen als „nicht veröffentlicht“ gekennzeichneten Google-Beitrag zeigen.
- Eine dezente Sektion: „Was Kundinnen sagen“ mit `Google-Bewertungen ansehen`-Button auf den bestätigten Link aus dem Briefing (`https://g.page/r/CWCMg9iC9hN9EBE/review` ist ein **Bewertung-schreiben**-Link, daher **nicht fälschlich als Bewertungen-ansehen-Link** labeln). Für das Ansehen der Rezensionen einen korrekten öffentlichen Google-Maps-Unternehmensprofil-Link ermitteln/verwenden. Wenn kein sicherer Link vorliegt, neutrales Label „HaarVinci auf Google“ oder vorerst nur „Bewertung abgeben“ am bestätigten Link verwenden.
- Keine ungeprüfte Sterneanzahl oder Review-Zahl behaupten; diese können sich ändern. Keine Texte aus Screenshots ungeprüft übernehmen.
- Presse: eigener kleiner Akzent „HaarVinci in den Kieler Nachrichten“. Vorhandener nachprüfbarer Link zum Beitrag über Emily Peter / Cornelia Mohan: `https://www.kn-online.de/lokales/kiel/ploetzlich-fielen-die-haare-aus-wie-emily-peter-aus-kiel-trotz-haarausfall-ihr-glueck-fand-ZLA5S3FALFFUNJHYKYGRSB36Z4.html`.
- Redaktionellen neutralen Hinweis mit externem Link gestalten, **keinen vollständigen Zeitungsartikel, Pressebild oder Screenshot ohne Lizenz** in die Website übernehmen; keine Heilversprechen oder medizinischen Eignungsaussagen daraus ableiten.

## G. WhatsApp – wesentlich besser erkennbar

Prüfe `src/components/FloatingWhatsApp.astro` und die zugehörigen Styles. In 1.0.3 wird das Floating-Element teilweise sehr aggressiv ausgeblendet, wenn beliebige Texte/Bilder im Bereich liegen. Ziel: **zuverlässig sichtbarer, sofort erkennbarer Kontaktbutton**.

- Auf mobilen Geräten gut erkennbarer WhatsApp-Knopf oder kleine beschriftete Kontakt-Pill mit Grün als Akzent, nicht nur ein unscheinbarer Bordeaux-Link.
- Kontrast, Mindest-Zielgröße, Tastaturbedienung und `aria-label` prüfen. Keine Überlagerung von Formularen, Cookie-Dialogen, Slidern oder wichtiger Navigation.
- Zusätzlich eindeutiger primärer Beratungs-CTA im Hero, Kontaktbereich und gegebenenfalls im mobilen Header.
- Kein automatischer Nachrichtenversand; nur expliziter Klick auf `wa.me`.
- Funktionstests speziell für 360, 390, 412 und 768 Pixel sowie am Ende der Seite durchführen.

## H. Technik, SEO und Release-Sicherheit

- Astro, vorhandene statische Auslieferung, bestehende Datenmodelle und vorhandene Tests erhalten.
- Design-Tokens zentral definieren und bestehende CSS-Farbwerte konsistent ersetzen.
- Responsive Bildgrößen, lazy-loading außerhalb des Heroes, WebP/AVIF soweit praktikabel; optimierte `alt`-Texte, keine privaten EXIF-Daten im Web-Build.
- Lighthouse-/Ladezeiten und sichtbare Layoutverschiebungen beachten, insbesondere bei vielen echten Ergebnissen.
- Zugänglicher Vorher-Nachher-Vergleich mit Tastatursteuerung, aussagekräftigen Labels und Fallback als Side-by-Side.
- Keine erfundenen Bewertungen, Preisregeln, Geschäftszeiten oder Zertifizierungen.
- Preis- und Fachinhalte aus `HaarVinci_Website_Briefing_Timo.md` beibehalten. Die ältere live geschaltete Homepage kann teils abweichende Angaben enthalten und ist nicht maßgeblich.
- `content/release.json` bleibt gesperrt, wenn Einwilligungen/Rechtstexte nicht vollständig vorliegen. Kein öffentlicher IONOS-Upload und keine Änderung an Domain/DNS/Mail.

## I. Abnahme und Lieferumfang

Bitte nach der Implementierung:
1. Website lokal starten und in allen Hauptbereichen visuell prüfen.
2. Vollständige Browser-/Funktionstests und neue Tests für Galerie, Anfahrt, WhatsApp.
3. Desktop- und Mobil-Screenshots (mindestens 390/412 und 1440 px) sowie einzelne Screenshots von Galerie und Anfahrt liefern.
4. Neue **einzelne offline-fähige HTML-Vorschau** für Conny erstellen, bei der die Bilder eingebettet sind. Nicht als Live-Website ausgeben.
5. Änderungsprotokoll: geänderte Dateien, verwendete Medien, ausstehende Freigaben und offene Fakten dokumentieren.
6. Soweit Git vorhanden: separaten Commit/Checkpoint für Version 1.1.
7. Keine weiteren Projektphasen (Kundenkonto, KI-Berater, Android-App-Anbindung) vorziehen.

**Definition of Done:** Die neue Website wirkt sichtbar hochwertiger, ihre echte Arbeit steht im Mittelpunkt, WhatsApp ist klar erreichbar, die Anfahrtsinformation löst Verwechslungen mit dem Imbiss und die Parkplatzlösung bleibt präzise ohne falsche Navigation. Die Seite bleibt technisch testbar und vor öffentlichem Livegang geschützt.
