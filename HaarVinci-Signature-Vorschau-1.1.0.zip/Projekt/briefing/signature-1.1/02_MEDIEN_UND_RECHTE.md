# Medienzuordnung, Rechte und Einsatz

## Geprüfte Paare (Bildinhalt nur zugeschnitten, nicht retuschiert)

| Fall | Vorher | Nachher | Status |
|---|---|---|---|
| 01 aschblond | 1000301960 | 1000301961 | Website-Freigabe Kundin prüfen |
| 02 rotbraun | 1000301962 | 1000301963 | Website-Freigabe Kundin prüfen |
| 03 braun / Winter | 1000301964 | 1000301965 | Website-Freigabe Kundin prüfen |
| 04 goldblond | 1000301966 | 1000301967 | Website-Freigabe Kundin prüfen |

**Achtung:** 04 enthält im Ursprungsbild einen WhatsApp-Text „Ohne extensions“; dieser wurde aus der Zuschnittfassung entfernt. Zuschneiden und Komprimieren ist keine Behandlungsretusche. Bitte Originale und Paare vor Veröffentlichung mit Conny prüfen.

## Sonstige Bilder

- **Studio original:** `03_Studio_und_Conny/studio_01.jpg` bis `studio_03.jpg` – echte Räumlichkeiten; darf in der Vorschau eingesetzt werden.
- **Conny:** `Conny_Originalfoto_Abendlicht_Screenshot.png` und `Conny_Originalfoto_Mallorca_Screenshot.png`; der textgestaltete KI-Entwurf ist gesondert gekennzeichnet.
- **Logos:** alle Varianten in `04_Logos/`. Nicht gleichzeitig als vollwertige Headerlogos verwenden.
- **Google-Bewertungen und Presse:** ausschließlich interne Inspiration / redaktioneller Verweis. Rechte an Rezensionstexten, Screenshots und redaktionellen Fotos nicht automatisch durch Zusendung eingeräumt.
- **Karten:** `05_Karten_NUR_Referenz/`; Screenshots von Google Maps nicht als eigene Website-Grafik veröffentlichen.

## Veröffentlichungskriterien

Jede abgebildete Kundin braucht eine für das konkrete Website-Medium geeignete Freigabe (und ggf. gesonderte Einwilligung zur Nutzung von Bewertungen/Testimonials). Besondere Zurückhaltung bei Gesundheitsthemen und medizinischen Geschichten. Vor Freigabe keine Kundinnenbilder öffentlich ausliefern. Im Zweifel zunächst nur Studio-/Conny-Fotos verwenden.
