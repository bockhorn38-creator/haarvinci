# Anfahrt & Parken – bestätigter Stand

**Studio:** HaarVinci, Eichhofstraße 16, 24116 Kiel, 1. Obergeschoss eines Wohngebäudes. Kein Ladengeschäft im Erdgeschoss. Der Imbiss unten ist nicht der Salon und soll nicht als Eingang suggeriert werden.

**Parken:** eigener angemieteter Kundenstellplatz am Eichkamp seit Oktober 2026 (Aussage Auftraggeber). Exakte Nummer, Hofeinfahrt und Zugangsweg zum Studio noch ungeklärt. Bis Conny dies bestätigt, nur „Stellplatz am Eichkamp nach Absprache“ kommunizieren. Kein automatisch erzeugter präziser Park-Pin.

**Sicherer Studio-Kartenlink** aus Connys Briefing: https://maps.app.goo.gl/KvQ4o5tsqVvmvv2L7?g_st=awb

**Kontakt wegen Parkplatz:** https://wa.me/4917631600586

**Website-Microcopy-Vorschlag:**

> Dein Besuch bei HaarVinci: Du findest mein persönliches Studio in der Eichhofstraße 16 im 1. Obergeschoss. Bitte gehe nicht in den Imbiss im Erdgeschoss. Für Kundinnen steht nach Absprache ein Parkplatz am Eichkamp zur Verfügung. Die genaue Zufahrt und den Stellplatz teile ich dir vor deinem Termin mit.

Zwei Aktionen: „Route zum Studio öffnen“ (externer Maps-Link) und „Parkplatzinfo per WhatsApp“ (vorgefüllte, aber nicht versendete Nachricht).

Die Screenshots `1000301970` und `1000301971` stammen aus Google Maps und dienen nur dazu, die Umgebung bzw. die grobe Lage des Parkbereichs zu verstehen. Sie belegen keine eindeutige Stellplatznummer oder für Kundinnen bestimmte Zufahrt.

**Später zusätzlich gewünscht:** echtes Haus-Eingangsfoto, Klingelschild/Etage und Foto des genauen Kundenparkplatzes. Nur aufnehmen und veröffentlichen, wenn Conny die Details ausdrücklich freigibt.
