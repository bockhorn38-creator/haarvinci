# HaarVinci 1.1 – Qualitätscheck für Codex

## Visuelle Prüfung
- [ ] Header / Logo lesbar auf 320, 360, 390, 412, 768 und 1440 px
- [ ] Farbwelt warmes Elfenbein + Schwarz + sparsame Gold-Akzente; ausreichend Kontrast
- [ ] Erste Bildschirmhöhe vermittelt HaarVinci und zeigt einen starken Kontakt-CTA
- [ ] Ergebnisgalerie gut sichtbar, keine falschen Bildpaarungen oder abgeschnittenen Haarspitzen
- [ ] „Über Conny“ benutzt reale oder ausdrücklich freigegebene gestalterische Porträts, keine irreführenden Studiohintergründe
- [ ] FAQ auf Smartphone leicht bedienbar, kein unnötig überlanger Block

## Funktionen
- [ ] WhatsApp mobil klar sichtbar; beim Scrollen erreichbar und nicht auf Texte/Formulare gelegt
- [ ] Externer Routen-Link führt zu Eichhofstraße 16, Kiel
- [ ] Parkplatzbutton öffnet WhatsApp-Anfrage; keine unbestätigte Route oder Hausnummer
- [ ] Bilder optimiert, Buttons auch mit Tastatur nutzbar, Alternativtexte sachlich
- [ ] Kontaktformular suggeriert keinen tatsächlich erfolgten Versand
- [ ] Vorher-Nachher-Slider (falls eingebaut) funktioniert mit Tastatur; sonst Side-by-Side

## Sicherheit / Freigaben
- [ ] Keine Google-Maps-Screenshots im öffentlichen Web-Build
- [ ] Keine Google-Reviews mit Status „nicht veröffentlicht“
- [ ] Keine KN-Artikel-Screenshots oder Bilder ohne Nutzungsrecht
- [ ] Kundinnenbilder nur in interner Vorschau, bis Website-Freigaben geprüft sind
- [ ] Öffentliche Release-Sperre bleibt bestehen, Impressum und Datenschutz nicht automatisch freigegeben
- [ ] Android-App, Domain, Mail, DNS und IONOS-Verträge unberührt

## Lieferung
- [ ] Tests bestanden oder Fehler dokumentiert
- [ ] Desktop-/Mobil-Screenshots der neuesten Version
- [ ] Einzelne eigenständige Handy-HTML-Vorschau mit eingebetteten Bildern
- [ ] Liste verwendeter Fotos + Dateipfade + noch fehlende Freigaben
- [ ] Git-Checkpoint/Commit für 1.1
