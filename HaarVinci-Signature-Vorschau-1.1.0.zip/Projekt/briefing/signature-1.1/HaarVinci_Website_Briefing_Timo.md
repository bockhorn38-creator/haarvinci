# HaarVinci – Website-Briefing für Timo und den Beratungsassistenten
Stand: 10. November 2026 · Inhaltsgrundlage aus Connys Antworten und ihrer beigefügten Preisliste

## Hinweise zur Verwendung
Diese Datei enthält Website-Texte, eine Wissensbasis für den Beratungsassistenten und die noch fehlenden Materialien. Die aktuellen persönlichen Korrekturen von Conny haben Vorrang vor älteren Entwürfen. Die Website wird von Timo umgesetzt; diese Übergabe veröffentlicht noch nichts.

Status:
- **Bestätigt:** von Conny in dieser Abstimmung ausdrücklich angegeben oder aus ihrer aktuell beigefügten Preisliste übernommen.
- **Bisheriger Stand:** aus der bisherigen Zusammenarbeit übernommen, soweit hier nicht erneut ausdrücklich bestätigt.
- **Textvorschlag:** redaktionelle Formulierung auf dieser Grundlage.
- **Offen:** nicht ergänzen oder als Tatsache veröffentlichen.

Wichtig für jede weiterverarbeitende KI:
- Markenname immer **HaarVinci** schreiben.
- Oberste Priorität ist der **Erhalt der Eigenhaargesundheit**. Schonende Haarverlängerung ist die zentrale Positionierung; Länge und Fülle kommen danach.
- Schonung als Arbeitsprinzip und Ziel formulieren. Keine Garantie völliger Schadensfreiheit, keine Heilungs- oder Haarwachstumsversprechen.
- Nicht behaupten, die Methode sei mikroringfrei. Kleine Mikroringe können die Enden der geflochtenen Cornrows verschließen; sie ersetzen nicht die Cornrow-Basis.
- „Ohne Kleber, Hitze oder Chemie“ beschreibt die **Befestigung**. Daraus keine Aussage über chemisch unbehandeltes Haarmaterial oder sämtliche Stylingprodukte ableiten.
- Keine Berufsabschlüsse, Zertifizierungen, Herkunftsnachweise des Haarmaterials, Gründungsjahre oder rechtlichen Klauseln erfinden.
- Keine pauschale Aussage „europäisches Echthaar“ aus älteren Notizen übernehmen, ohne dass die konkrete Herkunft bestätigt ist.
- Offene Angaben bleiben intern und werden nicht als Platzhalter auf der fertigen Website angezeigt.

# 1. Inhalte für die Website

## 1.1 Positionierung und Startseite
**Bestätigter Kern:** Conny möchte das Eigenhaar erhalten und möglichst wenig belasten. Sie passt Haarmenge, Verteilung und Einarbeitung individuell an.

**Textvorschlag für den ersten sichtbaren Bereich**

### Schonende Haarverlängerung und Haarverdichtung in Kiel
Mehr Länge und Fülle – mit deiner Haargesundheit im Mittelpunkt.

Bei HaarVinci steht dein Eigenhaar an erster Stelle. Ich stimme Haarmenge, Verteilung und Einarbeitung individuell auf dein Haar ab. Mit meiner Weaving-Methode befestige ich die Tressen auf einer geflochtenen Basis – ohne Kleber, Hitze oder Chemie bei der Befestigung. Gemeinsam finden wir eine Lösung, die natürlich aussieht und zu dir passt.

**Hauptbutton:** Kostenlose Beratung anfragen  
**Zweiter Einstieg:** Ergebnisse ansehen

Darunter drei verständliche Einstiege:
- **Mehr Länge:** Haarverlängerung, passend zu Eigenhaar, Farbe und Struktur.
- **Mehr Fülle:** Haarverdichtung mit individuell abgestimmter Haarmenge und Verteilung.
- **Lösung für den Oberkopf:** Persönliche Beratung zu Oberkopflösungen, beispielsweise einem Topper.

Die Schonung des Eigenhaars soll vor und innerhalb dieser drei Einstiege sichtbar bleiben, nicht nur als Nebensatz in den FAQ.

## 1.2 Leistungen und Methode
**Bestätigt:** Weaving auf Cornrow-Basis. Das Eigenhaar wird zu einer Basis geflochten; die Tressen werden daran angenäht. Zum Verschließen eines einzelnen Cornrows kann jeweils ein Mikroring verwendet werden. Pro Reihe sind es ungefähr vier, abhängig von der Ausführung. Alternativ können die Enden vernäht werden; Conny bespricht das mit der Kundin.

**Textvorschlag**
Ich arbeite mit Weaving: Die Haartressen werden an einer sorgfältig geflochtenen Cornrow-Basis angenäht. Dabei achte ich besonders darauf, die Haarmenge passend zu deinem Eigenhaar zu verteilen. Zum Sichern der Cornrow-Enden verwende ich je nach Absprache kleine Mikroringe oder vernähe die Enden.

100 g Haar werden häufig auf zwei Reihen verteilt. Bei feinerem oder weniger Eigenhaar können mehr Reihen nötig sein, um die Belastung besser zu verteilen. Deshalb ergibt sich die Reihenanzahl nicht allein aus dem Haargewicht.

**Bisheriger Stand:** Haarverlängerung, Haarverdichtung und individuelle Oberkopflösungen gehören zum Angebot. Tapes und Bondings sind keine angebotenen Einarbeitungsmethoden. Aus dem Entfernen fremder Bondings darf die KI kein Angebot zur Bonding-Einarbeitung ableiten. Genaue Technik und Preis einer Oberkopflösung werden persönlich geklärt.

## 1.3 Beratung, Vorbereitung und Bestellung
**Bisheriger Stand:** kostenlose Erstberatung, bis zu etwa 60 Minuten, persönliches Gespräch, Begutachtung von Eigenhaar und Kopfhaut, gegebenenfalls Testtresse. Keine medizinische Diagnose.

**Bestätigte Vorbereitung – Textvorschlag**
Komm zur Beratung möglichst mit frisch gewaschenen, ungestylten und luftgetrockneten Haaren. So kann ich deine natürliche Haarstruktur und Farbe am besten beurteilen.

Falls du deine Haare noch färben lassen möchtest, plane den Friseurtermin möglichst ein bis zwei Wochen vor unserer Beratung ein. Die Haare sollten danach bereits gewaschen worden sein. Direkt nach einer frischen Färbung kann die Farbe noch dunkler wirken und dazu führen, dass wir die Extensions zu dunkel auswählen.

**Ablauf für die Website**
1. **Beratung:** Wünsche, Eigenhaar und Möglichkeiten gemeinsam besprechen.
2. **Haarauswahl:** Farbe, Struktur, Länge und Haarmenge abstimmen; individuelles Angebot erstellen. Bisheriger Ablauf: Zusammenfassung per WhatsApp.
3. **Bezahlung und Bestellung:** Der vollständige Haarpreis wird vorab bezahlt und separat berechnet. Es handelt sich um die Vorauszahlung des Haarmaterials, nicht um einen beliebig angesetzten Teilbetrag.
4. **Terminvereinbarung:** Sobald die Kundin die Haare bezahlt hat, wird der Einarbeitungstermin verbindlich vereinbart. Die Lieferzeit wird bei der Planung berücksichtigt.
5. **Einarbeitung und Anpassung:** Haare einarbeiten und an das Eigenhaar anpassen. Die Dienstleistung wird separat am Termin berechnet.

**Bisheriger Lieferzeit-Richtwert:** circa sechs bis sieben Wochen. Nicht als garantierten Liefertermin formulieren; das aktuelle Zeitfenster wird persönlich abgestimmt.

## 1.4 Preise
**Quelle:** von Conny am 10.11.2026 beigefügte Preisliste „HaarVinci – Preisliste – Weaving“ (1000587620.png). Diese Fassung ersetzt ältere abweichende Angaben zu Zusatzleistungen.

### Basis-Service / Hochsetzen (Weaving)
| Anzahl gearbeiteter Reihen | Preis |
|---|---:|
| 1 Reihe | 80 € |
| 2 Reihen insgesamt | 160 € |
| 3 Reihen insgesamt | 220 € |
| Jede weitere Reihe | 65 € |

Der Basis-Service umfasst laut Preisliste:
- persönliche fachliche Erst-Beratung,
- fachgerechte Einarbeitung / Anpassung,
- sauberes Standard-Finish.

### Optional im Rahmen des Hochsetzens
| Leistung | Preis |
|---|---:|
| Seitliche Zusatzintegration, 2 Elemente | 35 € |
| Vorbereitung und Anpassung eines neuen Haarsatzes | 40 € |

Die 40 € betreffen den neuen Haarsatz beziehungsweise das Neuset; sie werden nicht automatisch bei jedem Nachsetztermin addiert. Die im Basis-Service enthaltene Anpassung nicht mit diesem Zusatzposten doppelt berechnen.

### Entfernen von Weaving – eigener Termin
| Anzahl Reihen | Preis |
|---|---:|
| 1 Reihe | 20 € |
| 2 Reihen | 35 € |
| 3 Reihen | 45 € |

Die Entfernungspreise beziehen sich ausdrücklich auf einen eigenen Entfernungstermin. Beim Hochsetzen wird das vorhandene Weaving ebenfalls entfernt und neu eingearbeitet; diese Tabelle nicht automatisch zusätzlich auf den Hochsetzpreis aufschlagen. Sonderaufwand persönlich klären.

### Zusatzmodule
| Leistung | Preis |
|---|---:|
| Form- und Spitzenanpassung | 20 € |
| Ponyschneiden | 15 € |
| Styling: Glätten oder Locken | 20 € |
| Sonderwünsche / Mehraufwand | nach Aufwand |

Bondings oder andere Fremdarbeiten werden hinsichtlich des Entfernens individuell nach Aufwand beurteilt. Für das Entfernen von mehr als drei Weaving-Reihen liegt hier kein bestätigter Preis vor.

### Individuelles Preisbeispiel für ein Neuset
| Bestandteil | Beispielpreis |
|---|---:|
| 50 g Echthaar, 40 cm | 220 € |
| Einarbeitung einer Reihe | 80 € |
| Vorbereitung / Anpassung des neuen Haarsatzes | 40 € |
| **Gesamt** | **340 €** |

**Textvorschlag zur Einordnung**
Dieses Beispiel zeigt eine mögliche Zusammenstellung. Dein persönlicher Gesamtpreis richtet sich nach Haarlänge, Haarmenge, Auswahl des Haares, benötigter Reihenanzahl und vereinbarten Zusatzleistungen. Wie viele Reihen für dein Eigenhaar sinnvoll sind, klären wir in der Beratung. Haarmaterial und Dienstleistung werden getrennt berechnet.

Der Haarpreis von 220 € wurde in der Abstimmung als bisheriger Kundenpreis für dieses Beispiel genannt. Daraus keine vollständige Haarpreisliste oder allgemeinen Gramm-Preis hochrechnen.

## 1.5 Nachsetzen, Entfernen und fremde Haare
**Bestätigt:** Nachsetzen gewöhnlich nach sechs bis zwölf Wochen, je nach Eigenhaar und Ausgangslage.

Hochsetzen bedeutet bei Conny: bestehende Einarbeitung entfernen, das Eigenhaar auskämmen, die Basis neu aufbauen und die Tressen erneut einarbeiten. Wenn die bestehende Verteilung oder Verarbeitung nicht zu ihrer Arbeitsweise passt, wird sie entsprechend angepasst.

**Textvorschlag für Fremdarbeiten**
Du kannst auch mit bereits vorhandenen Tressen oder einer Weaving-Einarbeitung aus einem anderen Studio zu mir kommen. Ich schaue mir Haar und Einarbeitung zunächst persönlich an. Beim Nachsetzen entferne ich die bisherige Einarbeitung und arbeite die Tressen nach meiner eigenen Weaving-Methode neu ein. Ob deine vorhandenen Haare dafür geeignet sind und welcher Aufwand entsteht, besprechen wir vorab.

**Interne Abgrenzung, kein fertiger Rechtstext:** Conny möchte für mitgebrachtes Fremdhaar keine Qualitäts- oder Haltbarkeitsgarantie abgeben. Ihre weitergehende Aussage zur Eigenverantwortung der Kundin bei Schäden ist nicht als veröffentlichungsfertige Haftungsregel übernommen. Falls solche Bedingungen verwendet werden sollen, muss die konkrete rechtliche Formulierung gesondert geklärt werden. Die KI darf daraus weder einen umfassenden Haftungsausschluss noch „Schäden gehen immer zulasten der Kundin“ machen.

## 1.6 Über Conny
**Textvorschlag – persönliche längere Fassung**
Haare haben mich schon mit 16, 17 fasziniert. Über mein damaliges persönliches Umfeld entdeckte ich Braids und Cornrows – und wollte unbedingt lernen, wie diese Flechttechniken funktionieren. Weil ich niemanden fand, der sie mir beibringen konnte, suchte ich selbst nach Lernmaterial. Schließlich fand ich eine Lehrkassette aus den USA. Mit dieser VHS begann mein Weg ins Flechthandwerk.

Später lernte ich in einem Haarverlängerungsforum andere Stylistinnen kennen. Aus dem Austausch entstanden Freundschaften, neue Kenntnisse und Erfahrungen mit unterschiedlichen Extensionsmethoden, die ich ausprobierte und zum Teil auch anbot. Ich beschäftigte mich außerdem mit den betriebswirtschaftlichen Grundlagen einer Selbstständigkeit und legte eine Prüfung bei der Handwerkskammer ab. Schließlich machte ich mich mit HaarVinci selbstständig.

Heute steht für mich eines an erster Stelle: die Gesundheit deines Eigenhaars. Deshalb arbeite ich mit meiner schonenden Weaving-Methode und stimme jede Einarbeitung individuell auf dein Haar ab. Mein Ziel ist ein natürliches Ergebnis, das zu dir passt – mit sorgfältiger Arbeit und ehrlicher Beratung.

**Kurze Fassung für die Startseite**
Ich bin Conny, die Frau hinter HaarVinci in Kiel. Meine Begeisterung für Braids und Cornrows führte mich zur Haarverlängerung – heute steht bei jeder Einarbeitung der Erhalt deines Eigenhaars an erster Stelle.

**Redaktionelle Grenzen:** Keine Meisterqualifikation und keinen abgeschlossenen BWL-Abschluss behaupten. Die genaue Prüfungsbezeichnung und ein Gründungsjahr sind nicht angegeben. Namen von Akademie und Forum wurden unsicher erinnert und deshalb nicht aufgenommen. Private Namen, die Beziehungsgeschichte und der Start aus der Arbeitslosigkeit sind für diesen öffentlichen Text nicht nötig. „Über zehn Jahre Erfahrung“ ist bisheriger Stand und kann nach Abgleich ergänzt werden.

## 1.7 Kontakt und Terminvereinbarung
| Feld | Angabe / Status |
|---|---|
| Marke | HaarVinci |
| Ansprechpartnerin | Conny |
| Geschäftliche Telefonnummer / WhatsApp | 0176 31600586 |
| International | +49 176 31600586 |
| WhatsApp-Link | https://wa.me/4917631600586 |
| Telefonlink | tel:+4917631600586 |
| Adresse | Eichhofstraße 16, 24116 Kiel |
| E-Mail (von Conny bestätigt) | info@haarvinci.de |
| E-Mail-Link | mailto:info@haarvinci.de |
| Instagram | https://www.instagram.com/haarvinci/ |
| Google Maps | https://maps.app.goo.gl/KvQ4o5tsqVvmvv2L7?g_st=awb |
| Google-Bewertungslink | https://g.page/r/CWCMg9iC9hN9EBE/review |

**Textvorschlag**
Termine sind ausschließlich nach Vereinbarung möglich. Du erreichst mich telefonisch, per WhatsApp oder per E-Mail. Über das Kontaktformular kannst du mir deinen Terminwunsch direkt mitteilen. Ich melde mich bei dir, um die Einzelheiten abzustimmen.

**Umsetzungsvorschlag für das Formular:** Name, bevorzugter Rückkontakt, Anliegen, Wunschtermin beziehungsweise Zeitfenster und freie Nachricht. Keine medizinischen Angaben als Pflichtfelder. Eine Anfrage ist noch keine bestätigte Buchung. Keine sofortige Verfügbarkeit suggerieren.

Buttons: „Beratung anfragen“, „WhatsApp schreiben“, „Anrufen“, „E-Mail schreiben“, „Anfahrt öffnen“, „Auf Google bewerten“.

# 2. Häufige Fragen und Wissensbasis für den Beratungsassistenten

Die folgenden Antworten sind Formulierungsvorschläge auf Basis der bestätigten Aussagen. Ausnahmen und individuelle Zusagen trifft Conny persönlich.

### Was ist Conny bei einer Haarverlängerung besonders wichtig?
Die Gesundheit und der Erhalt deines Eigenhaars stehen an erster Stelle. Deshalb werden Haarmenge, Reihenanzahl und Verteilung individuell angepasst.

### Arbeitest du mit Kleber oder Chemie?
Die Befestigung meiner Weaving-Methode erfolgt ohne Kleber, Hitze oder Chemie. Die Tressen werden an einer geflochtenen Cornrow-Basis angenäht.

### Werden dabei Mikroringe verwendet?
Je nach Absprache sichere ich die Enden der einzelnen Cornrows mit jeweils einem kleinen Mikroring. Pro Reihe sind es ungefähr vier. Alternativ kann ich die Enden vernähen. Die Tressen selbst werden an der geflochtenen Basis angenäht.

### Ist die Erstberatung kostenlos?
Nach dem bisherigen Beratungsangebot ist die Erstberatung kostenlos. Dabei besprechen wir deine Wünsche und schauen, welche Lösung zu deinem Haar passt.

### Wie soll ich zur Beratung kommen?
Möglichst mit frisch gewaschenen, ungestylten und luftgetrockneten Haaren. Falls du vorher färben lassen möchtest, möglichst ein bis zwei Wochen vor der Beratung und mit bereits erfolgten Haarwäschen nach dem Färben.

### Wann wird mein Einarbeitungstermin verbindlich?
Sobald du den Haarpreis bezahlt hast, vereinbaren wir den Einarbeitungstermin verbindlich. Die Bestellung und voraussichtliche Lieferzeit berücksichtigen wir dabei.

### Wie viele Reihen brauche ich?
Das hängt von deinem Eigenhaar und der Haarmenge ab. 100 g werden häufig auf zwei Reihen verteilt. Bei feinem oder weniger Eigenhaar kann eine Verteilung auf mehr Reihen sinnvoll sein. Conny entscheidet das nach persönlicher Begutachtung.

### Wann müssen die Haare hochgesetzt werden?
Üblicherweise nach sechs bis zwölf Wochen. Der passende Abstand wird individuell festgelegt. Beim Hochsetzen wird die vorhandene Einarbeitung entfernt und anschließend neu aufgebaut.

### Wie lange halten die Haare?
Bei entsprechender Pflege können die Haare bis zu einem Jahr halten. Wenn für die ausgewählten Haare etwas anderes gilt, bespricht Conny das persönlich mit dir. Die Haltbarkeit der Haare ist nicht die Dauer bis zum nächsten Hochsetzen und keine garantierte Mindesthaltbarkeit.

### Wie bürste ich die Haare richtig?
Beginne bei den Spitzen und bürste diesen Abschnitt vorsichtig nach unten. Setze dann schrittweise etwas höher an und bürste jeweils wieder nach unten, bis das Haar entwirrt ist. Halte dabei am Ansatz gegen oder lege deine Hand an den Kopf, damit möglichst wenig Zug auf das Eigenhaar und die Befestigung entsteht. Nicht vom Ansatz durch Knoten reißen.

### Kann ich Sport machen?
Ja. Nimm die Haare für den Sport passend zusammen. Danach können sie bei Bedarf gewaschen werden. Achte darauf, dass Kopfhaut, Ansätze und Cornrows anschließend wieder gut trocknen.

### Was gehört nach der Haarwäsche zur Pflege?
Nach jeder Wäsche mit Shampoo einen Conditioner verwenden, nach Connys bisherigen Pflegehinweisen in den Längen. Die Haare möglichst trocken föhnen; mindestens Kopfhaut, Ansätze und Cornrows sollen trocken sein. Die Längen dürfen für die anschließende Pflege noch handtuchtrocken sein.

### Wann verwende ich Serum oder Haaröl?
Conny empfiehlt, ein geeignetes Serum oder Haaröl sparsam auf die noch handtuchtrockenen Längen und Spitzen zu geben. Damit möchte sie die Feuchtigkeit in den Längen besser bewahren. Das ist ihre bevorzugte Pflegeroutine. Die KI soll daraus keine allgemeine Behauptung machen, Öl dürfe niemals auf trockenem Haar verwendet werden; Produktanwendung und individuelles Haar können unterschiedlich sein.

### Darf ich mit nassen Haaren schlafen?
Nein. Gehe erst schlafen, wenn auch die Längen trocken sind. Feuchte Haare können durch nächtliche Reibung geschädigt werden und verfilzen; schlecht durchtrocknende Bereiche können außerdem muffig riechen. „Handtuchtrockene Längen“ bezieht sich auf den Pflegeschritt nach dem Waschen, nicht auf das Schlafengehen.

### Welche Lösung passt zu meinen dünnen Haaren?
Das wird persönlich beurteilt. Je nach Ausgangslage kommen eine Haarverdichtung oder eine Oberkopflösung infrage. Entscheidend ist, was dein Eigenhaar sinnvoll tragen kann. Der Assistent darf eine Eignung nicht allein aus einer Nachricht oder einem Foto verbindlich zusagen.

### Kann ich Haare aus einem anderen Studio mitbringen?
Grundsätzlich ja. Conny prüft Haar und Einarbeitung und arbeitet nach ihrer eigenen Weaving-Methode neu ein. Für fremdes Haar werden keine Qualitäts- oder Haltbarkeitsversprechen gemacht. Verbindliche Aussagen zu Eignung und Aufwand erfolgen persönlich.

### Entfernst du auch Bondings oder andere Fremdarbeiten?
Das wird individuell nach Aufwand beurteilt. Bitte beschreibe bei der Anfrage, welche Methode du trägst und was entfernt werden soll.

### Was kostet meine Behandlung?
Die veröffentlichten Reihenpreise und das Beispiel von 340 € können erläutert werden. Ein verbindliches persönliches Angebot erstellt Conny nach der Beratung. Keine festen Pakete aus Haargewicht und Reihenanzahl ableiten.

### Wann soll der Assistent an Conny weitergeben?
Bei persönlicher Eignung, Beschwerden, starkem Zug oder Problemen mit der Einarbeitung, deutlich verändertem Haarzustand, Fremdarbeiten, Reklamationen, Sonderwünschen, individuellen Angeboten und Terminbestätigungen. Keine Diagnosen, pauschalen Entwarnungen oder rechtlichen Zusagen erteilen.

### Was ist für eine erste Anfrage hilfreich?
Der gewünschte Effekt (Länge, Fülle oder Oberkopf), ungefähre Eigenhaarlänge, bereits vorhandene Extensions samt Methode sowie mögliche Terminzeiten. Fotos können nach Absprache freiwillig direkt an Conny geschickt werden. Verfügbarkeit oder Preis werden nicht automatisch bestätigt.

# 3. Materialien, Gestaltung und offene Punkte

## 3.1 Bereits vorhanden
- Inhaltliche Antworten und persönliche Geschichte.
- Aktuelle Dienstleistungspreisliste mit Entfernungspreisen.
- Telefonnummer, bestätigte E-Mail-Adresse und Anschrift.
- Instagram-, Google-Maps- und Bewertungslink.
- Fünf von Conny bereitgestellte Logovarianten.
- Dieses Briefing als Textgrundlage für Timo und seine KI.

## 3.2 Bilddateien im Übergabepaket
Die Originaldateien wurden unverändert übernommen und zur Orientierung umbenannt.

| Datei im Ordner assets | Ursprünglicher Upload | Inhalt |
|---|---|---|
| 01_Preisliste_Weaving.png | 1000587620.png | Schwarze Preisliste mit goldenen Elementen |
| 02_Logo_Schriftzug_Schwarz.png | 1000585191.png | Schwarzer Schriftzug auf weißem Grund |
| 03_Logo_Schriftzug_Gold_Krone.png | 1000585190.png | Goldener Schriftzug mit Krone auf dunklem Grund |
| 04_Logo_Frau_Kreis_Hell.png | 1000585217.png | Frau und Schrift im hellen runden Emblem |
| 05_Logo_Frau_Kreis_Freigestellt.png | 1000585237.png | Goldener Kreis mit Frau und Schrift, mit Alpha-Kanal |
| 06_Logo_Frau_Ohne_Kreis.png | 1000585254.png | Frau und Schrift ohne Kreis, mit goldenem Hintergrundeffekt |

**Gestalterische Empfehlung:** Den einfachen Schriftzug im Kopfbereich der Website verwenden, damit er auch auf dem Handy gut lesbar bleibt. Die Variante mit Frau kann an einer größeren Stelle ergänzend eingesetzt werden. Timo darf die passende Variante auswählen; eine endgültige Hauptlogo-Entscheidung ist noch nicht getroffen. Nicht alle Varianten gleichzeitig als gleichberechtigte Hauptlogos einsetzen.

Die gelieferten Dateien sind Rasterbilder. Ein vorhandener Alpha-Kanal bedeutet nicht automatisch, dass alle unerwünschten Hintergrundreste sauber entfernt sind. Vor Verwendung auf hellen und dunklen Hintergründen Kanten und Lesbarkeit prüfen. Keine Vektordatei behaupten.

**Bisheriger Gestaltungsrahmen:** warme helle Töne, Beige / Kaschmir / Rosé, gezielte goldene Akzente; persönlich und hochwertig. Echte Ergebnisbilder und Connys Persönlichkeit sollen die Website tragen.

## 3.3 Noch von Conny auszuwählen
- Ein besonders starkes Nachher-Foto als Lieblingsresultat für die Startseite.
- Insgesamt drei Vorher-nachher-Paare: jeweils dieselbe Kundin vorher und nachher, also mindestens sechs Fotos. Möglichst Beispiele für mehr Länge und mehr Fülle.
- Pro Beispiel: Ausgangslage, Wunsch und tatsächlich durchgeführte Behandlung. Keine Mengen, Methoden oder Ergebnisse erfinden.
- Ein echtes Porträt oder Arbeitsfoto von Conny.
- Ein bis zwei kurze Originalvideos, zum Beispiel Haar in Bewegung oder ein Einblick in die Einarbeitung.
- Klare Kennzeichnung, für welche Kundenfotos und Videos die Veröffentlichung freigegeben ist. Nicht aus der bloßen Zusendung auf eine Freigabe schließen.
- Falls einzelne Bewertungen auf der Website zitiert werden sollen: Auswahl der Zitate und Klärung der Verwendung. Der Bewertungslink selbst ist noch keine Freigabe für einzelne Zitate.

Für den ersten visuellen Entwurf reichen ein Lieblingsresultat, ein Vorher-nachher-Paar und ein Foto von Conny. Weitere Galerieinhalte können nachgereicht werden.

## 3.4 Verbleibende offene Angaben
1. **Betriebliche Pflichtangaben für die Website:** Impressums- und Datenschutzinhalte gesondert vervollständigen; aus diesem Briefing keinen fertigen Rechtstext generieren.
2. **Fremdhaar-Bedingungen:** Falls gewünscht, gesondert abgestimmte Formulierung; kein pauschaler Haftungsausschluss aus den mündlichen Angaben.
3. **Fotoauswahl, Freigaben und gegebenenfalls ausgewählte Bewertungen** wie oben.
4. **Hauptlogo auswählen.** Die Auswahl ist Timo überlassen.
5. **Bisherige Angaben vor Veröffentlichung abgleichen:** Beratungsdauer von bis zu 60 Minuten, ungefähr sechs bis sieben Wochen Lieferzeit sowie „über zehn Jahre Erfahrung“, falls diese Detailangaben verwendet werden.

## 3.5 Empfohlene Seitenstruktur
Startseite mit Eigenhaargesundheit als zentraler Botschaft → Leistungen (Länge / Fülle / Oberkopf) → Methode und Beratungsablauf → echte Ergebnisse → Preise mit Beispiel und Folgekosten → Über Conny → FAQ → Kontakt und Anfahrt.

Die Website soll zu einer persönlichen Beratung führen. Ein Kontaktformular oder Beratungsassistent ersetzt weder Connys Begutachtung noch ihre Terminbestätigung.

