import fs from 'node:fs';
if (process.env.HAARVINCI_PRIVATE_PREVIEW === 'true') {
  console.error('Öffentlicher Release gesperrt: private Bildvorschau ist aktiv.');
  process.exit(1);
}

const gates = JSON.parse(
  fs.readFileSync(new URL('../content/release.json', import.meta.url), 'utf8'),
);
const missing = Object.entries(gates)
  .filter(([, approved]) => approved !== true)
  .map(([name]) => name);
for (const name of ['impressum', 'datenschutz']) {
  const path = new URL(`../content/legal/${name}.html`, import.meta.url);
  if (!fs.existsSync(path)) missing.push(`Vollständiger freigegebener Rechtstext: ${name}.html`);
}
if (missing.length) {
  console.error('Öffentliche Veröffentlichung noch gesperrt:\n- ' + missing.join('\n- '));
  process.exit(1);
}
console.error(
  'Freigaben vorhanden. Vor einer Veröffentlichung zusätzlich die dokumentierte manuelle Prüfung durchführen.',
);
