// Eine einzige weitergebbare HTML-Datei aus der vorhandenen privaten Vorschau.
// Keine Änderung am regulären Webhosting-Build und keine neuen Website-Inhalte.
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = fileURLToPath(new URL('../', import.meta.url));
const target = path.resolve(root, process.env.HAARVINCI_PREVIEW_OUTPUT || 'offline-preview');
const dist = path.resolve(root, process.env.HAARVINCI_PREVIEW_DIST || 'dist');
if (![dist, target].every((folder) => folder.startsWith(root)))
  throw new Error('Vorschaupfad muss innerhalb des Website-Projekts liegen.');
const privateRoot = path.join(root, '.private-preview') + path.sep;
if (
  (process.env.HAARVINCI_PRIVATE_PREVIEW === 'true' || dist.startsWith(privateRoot)) &&
  (!dist.startsWith(privateRoot) || !target.startsWith(privateRoot))
)
  throw new Error(
    'Private Bildvorschauen dürfen nur innerhalb von .private-preview/ exportiert werden.',
  );
let html = await fs.readFile(path.join(target, 'HaarVinci-Vorschau.html'), 'utf8');
if (!html.includes('noindex, nofollow, noarchive'))
  throw new Error('Einzeldatei ausschließlich aus der internen Vorschau exportieren.');

const sections = [];
for (const [file, id, title] of [
  ['Impressum.html', 'einzeldatei-impressum', 'Impressum'],
  ['Datenschutz.html', 'einzeldatei-datenschutz', 'Datenschutz'],
]) {
  const page = await fs.readFile(path.join(target, file), 'utf8');
  const main = page.match(/<main\b[^>]*>([\s\S]*?)<\/main>/);
  if (!main) throw new Error(`Vorschautext fehlt: ${file}`);
  // Die rechtlichen Entwürfe bleiben unverändert; nur Überschriftenhierarchie
  // und äußerer Abstand werden an die gemeinsame Datei angepasst.
  const content = main[1]
    .replace('class="shell legal-content"', 'class="legal-content"')
    .replace(/<(\/?)(h[12])\b/g, (_, slash, tag) => `<${slash}${tag === 'h1' ? 'h3' : 'h4'}`);
  sections.push(`<details id="${id}"><summary>${title} · Entwurf</summary>${content}</details>`);
}

html = html.replace('<body>', '<body id="anfang">');
html = html.replace(
  '</main>',
  `<section class="single-file-legal shell" aria-labelledby="vorschau-hinweise"><h2 id="vorschau-hinweise">Hinweise zur Vorschau</h2>${sections.join('')}</section></main>`,
);
html = html
  .replace(/href="HaarVinci-Vorschau\.html(#[^"]*)?"/g, (_, hash) => `href="${hash || '#anfang'}"`)
  .replaceAll('href="Impressum.html"', 'href="#einzeldatei-impressum"')
  .replaceAll('href="Datenschutz.html"', 'href="#einzeldatei-datenschutz"');

const licenses = [];
for (const file of ['Manrope-OFL.txt', 'Cormorant-Garamond-OFL.txt']) {
  licenses.push({ file, text: await fs.readFile(path.join(dist, 'lizenzen', file), 'utf8') });
}
// Die Lizenzen der ebenfalls eingebetteten Schriftdateien reisen mit.
const licenseData = JSON.stringify(licenses).replaceAll('<', '\\u003c');
html = html.replace(
  '</head>',
  `<style>
.single-file-legal { padding-block: 36px 60px; }
.single-file-legal > h2 { font-size: 2rem; margin-bottom: 25px; }
.single-file-legal > details { border-top: 1px solid var(--line); padding-block: 18px; }
.single-file-legal > details > summary { cursor: pointer; font-size: 14px; font-weight: 650; min-height: 44px; padding-block: 10px; }
.single-file-legal .legal-content { padding: 8px 0 24px; }
.single-file-legal h3 { font-family: var(--serif); font-size: 2rem; margin-block: 25px; }
.single-file-legal h4 { font-family: var(--serif); font-size: 1.5rem; font-weight: 400; margin-block: 25px 15px; }
</style><script type="application/json" id="haarvinci-schriftlizenzen">${licenseData}</script></head>`,
);
html = html.replace(
  '</body>',
  `<script>
(() => {
  const reveal = () => {
    const id = location.hash.slice(1);
    if (!['einzeldatei-impressum', 'einzeldatei-datenschutz'].includes(id)) return;
    const details = document.getElementById(id);
    if (details instanceof HTMLDetailsElement) details.open = true;
  };
  document.querySelectorAll('a[href^="#einzeldatei-"]').forEach(link => {
    link.addEventListener('click', () => {
      const details = document.getElementById(link.getAttribute('href').slice(1));
      if (details instanceof HTMLDetailsElement) details.open = true;
    });
  });
  window.addEventListener('hashchange', reveal);
  reveal();
})();
</script></body>`,
);

if (/\b(?:src|href)="(?!data:|#|https:|mailto:|tel:)[^"]+"/.test(html))
  throw new Error('Die Einzeldatei enthält noch einen lokalen Dateiverweis.');
await fs.writeFile(path.join(target, 'HaarVinci-fuer-Conny.html'), html);
console.log(
  `Einzeldatei für Conny erstellt: ${(Buffer.byteLength(html) / 1_000_000).toFixed(1)} MB, ohne Begleitdateien.`,
);
