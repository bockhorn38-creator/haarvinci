import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
const root = fileURLToPath(new URL('../', import.meta.url));
const supplied = process.argv[2];
if (!supplied)
  throw new Error('Aufruf: npm run import:signature -- PFAD_ZUM_ENTPACKTEN_UEBERGABEORDNER');
const pairs = JSON.parse(await fs.readFile(path.join(root, 'content/paired-results.json'), 'utf8'));
const ready = [];
for (const entry of pairs.flatMap((pair) => [pair.before, pair.after])) {
  const candidates = [
    path.resolve(supplied, '02_Neue_Ergebnisse/Bereit_zur_Pruefung', entry.file),
    path.resolve(supplied, entry.file),
  ];
  let bytes;
  for (const file of candidates) {
    try {
      bytes = await fs.readFile(file);
      break;
    } catch (error) {
      if (error.code !== 'ENOENT') throw error;
    }
  }
  if (!bytes) throw new Error(`Datei fehlt im Übergabepaket: ${entry.file}`);
  if (createHash('sha256').update(bytes).digest('hex') !== entry.sha256)
    throw new Error(`Prüfsumme stimmt nicht: ${entry.file}. Keine automatische Übernahme.`);
  ready.push({ file: entry.file, bytes });
}
const target = path.join(root, '.private-media/signature-1.1');
await fs.mkdir(target, { recursive: true });
for (const entry of ready) await fs.writeFile(path.join(target, entry.file), entry.bytes);
console.log(
  'Acht Originalbilder geprüft und ausschließlich privat importiert. Keine Foto-Freigabe geändert.',
);
