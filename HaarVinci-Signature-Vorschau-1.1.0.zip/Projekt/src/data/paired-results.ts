import catalog from '../../content/paired-results.json';
import { readFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { resolve } from 'node:path';
import sharp from 'sharp';
import { isRelease } from './publication';

export const isPrivatePreview = process.env.HAARVINCI_PRIVATE_PREVIEW === 'true';
if (isPrivatePreview && isRelease)
  throw new Error('Private Bildvorschau und öffentlicher Release dürfen nicht kombiniert werden.');

type Picture = { src: string; srcset: string; width: number; height: number; alt: string };
export type PairedResult = {
  id: string;
  title: string;
  before: Picture;
  after: Picture;
  needsReview: boolean;
};

export async function loadPairedResults(): Promise<PairedResult[]> {
  // Globale Livefreigaben ersetzen niemals einzelne Foto-/Paarfreigaben.
  const visible = catalog.filter(
    (item) => isPrivatePreview || (item.websiteApproved === true && item.pairConfirmed === true),
  );
  const results: PairedResult[] = [];
  for (const item of visible) {
    const source = resolve(
      process.cwd(),
      isPrivatePreview ? '.private-media/signature-1.1' : 'assets-source/approved-results',
    );
    const picture = async (entry: typeof item.before): Promise<Picture> => {
      let bytes: Buffer;
      try {
        bytes = await readFile(resolve(source, entry.file));
      } catch {
        throw new Error(
          `Galeriebild fehlt: ${entry.file}. Zuerst npm run import:signature -- PFAD ausführen.`,
        );
      }
      if (createHash('sha256').update(bytes).digest('hex') !== entry.sha256)
        throw new Error(`Prüfsumme des Galeriebildes stimmt nicht: ${entry.file}`);
      const { info } = await sharp(bytes).rotate().toBuffer({ resolveWithObject: true });
      const variants = [];
      for (const size of [...new Set([240, 360, 540, 720].map((w) => Math.min(w, info.width)))]) {
        const optimized = await sharp(bytes)
          .rotate()
          .resize({ width: size, withoutEnlargement: true })
          .webp({ quality: 86, effort: 5 })
          .toBuffer();
        variants.push({
          src: `data:image/webp;base64,${optimized.toString('base64')}`,
          width: size,
        });
      }
      // Unfreigegebene Bilder ausschließlich in die getrennte private HTML-Datei
      // einbetten. Niemals nach public/ oder in öffentliche Downloads schreiben.
      return {
        width: info.width,
        height: info.height,
        alt: entry.alt,
        src: variants.at(-1)!.src,
        srcset: variants.map((v) => `${v.src} ${v.width}w`).join(', '),
      };
    };
    results.push({
      id: item.id,
      title: item.title,
      before: await picture(item.before),
      after: await picture(item.after),
      needsReview: !item.pairConfirmed || !item.websiteApproved,
    });
  }
  return results;
}

export const pairedResults = await loadPairedResults();
