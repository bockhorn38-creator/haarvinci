import checklist from '../../content/release.json';
import { existsSync, readFileSync } from 'node:fs';
import { resolve } from 'node:path';

export const isRelease = import.meta.env.HAARVINCI_RELEASE === 'true';
if (isRelease && process.env.HAARVINCI_PRIVATE_PREVIEW === 'true') {
  throw new Error(
    'Private Kundinnenbilder dürfen nicht in einen öffentlichen Release übernommen werden.',
  );
}
if (isRelease && !Object.values(checklist).every((value) => value === true)) {
  throw new Error(
    'Öffentliche Veröffentlichung nicht freigegeben. Interne Vorschau mit npm run build verwenden.',
  );
}
export function legalText(name: 'impressum' | 'datenschutz') {
  if (!isRelease) return '';
  const file = resolve(process.cwd(), 'content', 'legal', `${name}.html`);
  if (!existsSync(file)) throw new Error(`Vollständiger Rechtstext fehlt: ${name}`);
  return readFileSync(file, 'utf8');
}
