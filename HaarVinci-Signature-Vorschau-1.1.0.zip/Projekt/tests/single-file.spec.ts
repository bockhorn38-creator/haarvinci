import { test, expect } from '@playwright/test';
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';

const file = resolve('offline-preview/HaarVinci-fuer-Conny.html');

test('eine einzelne HTML-Datei enthält alle Bilder, Schriften und zugehörigen Lizenzen', () => {
  const html = readFileSync(file, 'utf8');
  expect(Buffer.byteLength(html)).toBeLessThan(5_000_000);
  expect(html).toContain('noindex, nofollow, noarchive');
  expect(html).not.toMatch(/href="(?:HaarVinci-Vorschau|Impressum|Datenschutz)\.html/);
  expect(html).not.toMatch(/<(?:script|img)\b[^>]*src="(?!data:)/);
  const data = html.match(
    /<script type="application\/json" id="haarvinci-schriftlizenzen">([\s\S]*?)<\/script>/,
  );
  const licenses = JSON.parse(data![1]);
  expect(licenses).toHaveLength(2);
  for (const license of licenses)
    expect(license.text).toBe(readFileSync(resolve('dist/lizenzen', license.file), 'utf8'));
});

test('Connys Einzeldatei funktioniert offline mit Navigation, Galerie, WhatsApp und Rechtsentwürfen', async ({
  page,
  context,
}) => {
  await context.setOffline(true);
  await context.route('http://127.0.0.1:4322/einzeldatei.html', (route) =>
    route.fulfill({ path: file, contentType: 'text/html' }),
  );
  const requests: string[] = [];
  const errors: string[] = [];
  page.on('request', (request) => {
    if (request.url().startsWith('http')) requests.push(request.url());
  });
  page.on('pageerror', (error) => errors.push(error.message));
  await page.setViewportSize({ width: 412, height: 915 });
  await page.emulateMedia({ reducedMotion: 'reduce' });
  await page.goto('/einzeldatei.html');
  await expect(page.locator('h1')).toHaveCount(1);
  await expect(page.locator('.header-whatsapp')).toBeInViewport({ ratio: 1 });
  await expect(page.locator('.header-whatsapp')).toHaveAttribute(
    'href',
    'https://wa.me/4917631600586',
  );
  await page.getByRole('button', { name: 'Menü', exact: true }).click();
  await page.locator('.main-nav').getByRole('link', { name: 'Preise', exact: true }).click();
  await expect(page).toHaveURL(/einzeldatei\.html#preise$/);
  await expect(page.locator('.menu-toggle')).toHaveAttribute('aria-expanded', 'false');
  await page.locator('.gallery-open').first().click();
  await expect(page.getByRole('dialog')).toBeVisible();
  await page.keyboard.press('Escape');
  for (const id of ['impressum', 'datenschutz']) {
    await page.locator(`.footer-bottom a[href="#einzeldatei-${id}"]`).click();
    const details = page.locator(`#einzeldatei-${id}`);
    await expect(details).toHaveAttribute('open', '');
    await expect(details).toContainText(
      'vollständige, freigegebene Rechtstext liegt noch nicht vor',
    );
  }
  for (const img of await page.locator('main img:visible').all()) {
    await img.scrollIntoViewIfNeeded();
    await img.evaluate((e: HTMLImageElement) => e.decode());
    expect(await img.evaluate((e: HTMLImageElement) => e.naturalWidth)).toBeGreaterThan(0);
  }
  const brokenAnchors = await page
    .locator('a[href^="#"]')
    .evaluateAll((links) =>
      links
        .map((link) => link.getAttribute('href')!)
        .filter((href) => !document.getElementById(href.slice(1))),
    );
  expect(brokenAnchors).toEqual([]);
  expect(requests).toEqual(['http://127.0.0.1:4322/einzeldatei.html']);
  expect(errors).toEqual([]);
});

test('Einzeldatei bleibt ohne JavaScript bedienbar auf Smartphone und PC', async ({ browser }) => {
  const context = await browser.newContext({ javaScriptEnabled: false, offline: true });
  await context.route('http://127.0.0.1:4322/einzeldatei.html', (route) =>
    route.fulfill({ path: file, contentType: 'text/html' }),
  );
  const page = await context.newPage();
  for (const width of [320, 1440]) {
    await page.setViewportSize({ width, height: 850 });
    await page.goto('http://127.0.0.1:4322/einzeldatei.html');
    await expect(page.locator('.header-whatsapp')).toBeInViewport({ ratio: 1 });
    const details = page.locator('#einzeldatei-impressum');
    await details.locator('summary').click();
    await expect(details).toHaveAttribute('open', '');
    expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBeLessThanOrEqual(
      width,
    );
  }
  await context.close();
});
