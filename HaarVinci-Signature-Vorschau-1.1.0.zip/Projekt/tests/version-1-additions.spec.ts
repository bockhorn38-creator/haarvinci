import { test, expect } from '@playwright/test';
import sharp from 'sharp';
import { readFileSync } from 'node:fs';
import AxeBuilder from '@axe-core/playwright';

const title = 'HaarVinci | Schonende Haarverlängerung & Haarverdichtung in Kiel';

test('passende SEO- und vollständige Open-Graph-Daten mit echter Markengrafik', async ({
  page,
  request,
}) => {
  const descriptions = new Set();
  for (const route of ['/', '/impressum/', '/datenschutz/', '/404.html']) {
    await page.goto(route);
    const description = await page.locator('meta[name="description"]').getAttribute('content');
    expect(description!.length).toBeGreaterThan(50);
    descriptions.add(description);
    const pageTitle = await page.title();
    await expect(page.locator('meta[property="og:title"]')).toHaveAttribute('content', pageTitle);
    await expect(page.locator('meta[property="og:description"]')).toHaveAttribute(
      'content',
      description!,
    );
    await expect(page.locator('meta[property="og:url"]')).toHaveAttribute(
      'content',
      new URL(route, 'https://haarvinci.de').href,
    );
    await expect(page.locator('meta[property="og:locale"]')).toHaveAttribute('content', 'de_DE');
    await expect(page.locator('meta[property="og:image:type"]')).toHaveAttribute(
      'content',
      'image/png',
    );
    await expect(page.locator('meta[property="og:image:width"]')).toHaveAttribute(
      'content',
      '1200',
    );
    await expect(page.locator('meta[property="og:image:height"]')).toHaveAttribute(
      'content',
      '630',
    );
    await expect(page.locator('meta[property="og:image:alt"]')).toHaveAttribute(
      'content',
      /HaarVinci.*Logo/,
    );
    await expect(page.locator('meta[name="twitter:card"]')).toHaveAttribute(
      'content',
      'summary_large_image',
    );
    const image = await page.locator('meta[property="og:image"]').getAttribute('content');
    expect(image).toBe('https://haarvinci.de/social/haarvinci-signature-1.1.png');
    await expect(page.locator('meta[name="twitter:image"]')).toHaveAttribute('content', image!);
    const response = await request.get(new URL(image!).pathname);
    expect(response.status()).toBe(200);
    const metadata = await sharp(await response.body()).metadata();
    expect([metadata.width, metadata.height, metadata.format]).toEqual([1200, 630, 'png']);
    // Unvollständige Rechtsseiten bleiben bis zum separaten Livegang nicht indexierbar.
    await expect(page.locator('meta[name="robots"]')).toHaveAttribute('content', /noindex/);
  }
  expect(descriptions.size).toBe(4);
  await page.goto('/');
  await expect(page).toHaveTitle(title);
  await expect(page.locator('link[rel="icon"][type="image/svg+xml"]')).toHaveAttribute(
    'href',
    '/favicon.svg',
  );
  const svg = await (await request.get('/favicon.svg')).text();
  expect(svg).toContain('<image');
  expect(svg).toContain('data:image/png;base64,');
  for (const [path, size] of [
    ['/favicon-32.png', 32],
    ['/favicon-48.png', 48],
    ['/apple-touch-icon.png', 180],
  ] as const) {
    const response = await request.get(path);
    expect(response.status()).toBe(200);
    const metadata = await sharp(await response.body()).metadata();
    expect([metadata.width, metadata.height]).toEqual([size, size]);
  }
});

for (const width of [320, 390, 412, 1440]) {
  test(`echtes bestätigtes Conny-Porträt vollständig und ohne zusätzliche Bildtexte bei ${width}px`, async ({
    page,
  }) => {
    await page.setViewportSize({ width, height: 900 });
    await page.goto('/');
    await page.emulateMedia({ reducedMotion: 'reduce' });
    const photo = page.locator('#conny .approved-portrait');
    await photo.scrollIntoViewIfNeeded();
    await expect(photo).toHaveAttribute('src', /conny-sonnenlicht-.*\.webp/);
    await expect(photo).toHaveAttribute('alt', /Originalporträt von Conny/);
    const original = JSON.parse(readFileSync('src/data/media.json', 'utf8'))['conny-sonnenlicht'];
    await expect(photo).toHaveAttribute('width', String(original.width));
    await expect(photo).toHaveAttribute('height', String(original.height));
    await expect(photo).toHaveCSS('object-fit', 'contain');
    const bounds = (await photo.boundingBox())!;
    expect(bounds.height / bounds.width).toBeCloseTo(original.height / original.width, 2);
    await expect(page.locator('#conny .about-copy .eyebrow')).toHaveText(
      'DIE FRAU HINTER HAARVINCI',
    );
    await expect(page.locator('#conny .about-copy')).toContainText('der Erhalt deines Eigenhaars');
    expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(
      true,
    );
    if ([390, 1440].includes(width))
      await page.screenshot({ path: `test-results/conny-zusatz-${width}.png` });
  });
}

for (const [width, height] of [
  [320, 568],
  [360, 640],
  [390, 844],
  [412, 915],
  [600, 800],
]) {
  test(`mobiler WhatsApp-Kontakt erreichbar und ohne Inhaltsüberdeckung bei ${width}x${height}`, async ({
    page,
  }) => {
    await page.setViewportSize({ width, height });
    await page.emulateMedia({ reducedMotion: 'reduce' });
    await page.goto('/');
    await page.evaluate(() => document.fonts.ready);
    const link = page.locator('.floating-whatsapp');
    await expect(link).toHaveAttribute('href', 'https://wa.me/4917631600586');
    await expect(link).toHaveAttribute('target', '_blank');
    let visibleAt = -1;
    const total = await page.evaluate(() => document.documentElement.scrollHeight);
    for (let top = 0; top < total - height; top += Math.floor(height / 3)) {
      await page.evaluate((top) => window.scrollTo({ top, behavior: 'instant' }), top);
      await page.evaluate(
        () => new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(resolve))),
      );
      if (await link.isVisible()) {
        const rect = (await link.boundingBox())!;
        expect(rect.width).toBeGreaterThanOrEqual(48);
        expect(rect.height).toBeGreaterThanOrEqual(48);
        expect(rect.x).toBeGreaterThanOrEqual(0);
        expect(rect.x + rect.width).toBeLessThanOrEqual(width);
        expect(rect.y + rect.height).toBeLessThanOrEqual(height);
        const covered = await link.evaluate((button) => {
          const a = button.getBoundingClientRect();
          return Array.from(
            document.querySelectorAll(
              'main a, main button, main input, main textarea, main select, main summary, main p, main h1, main h2, main h3, main table, main img, .site-footer a',
            ),
          )
            .filter((item) => {
              if (item.closest('dialog:not([open]),[hidden]')) return false;
              const b = item.getBoundingClientRect();
              return (
                b.width > 0 &&
                b.height > 0 &&
                a.left < b.right &&
                a.right > b.left &&
                a.top < b.bottom &&
                a.bottom > b.top
              );
            })
            .map((item) => item.tagName);
        });
        expect(covered).toEqual([]);
        visibleAt = top;
        break;
      }
    }
    expect(visibleAt).toBeGreaterThanOrEqual(0);
    await expect(link).toHaveAccessibleName('Conny per WhatsApp kontaktieren');
    await link.focus();
    await expect(link).toBeFocused();
    await link.evaluate((anchor) =>
      anchor.addEventListener('click', (event) => {
        event.preventDefault();
        document.documentElement.dataset.clickedWhatsapp = (anchor as HTMLAnchorElement).href;
      }),
    );
    await link.click();
    await expect(page.locator('html')).toHaveAttribute(
      'data-clicked-whatsapp',
      'https://wa.me/4917631600586',
    );
    if (width === 390) {
      await page.screenshot({ path: 'test-results/whatsapp-mobil.png' });
      const accessibility = await new AxeBuilder({ page })
        .include('.floating-whatsapp')
        .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'])
        .analyze();
      expect(accessibility.violations).toEqual([]);
    }
    await page.getByRole('button', { name: 'Menü', exact: true }).click();
    await expect(link).toBeVisible();
    await page.keyboard.press('Escape');
    await page.locator('.gallery-open').first().click();
    await expect(page.getByRole('dialog')).toBeVisible();
    await expect(page.getByRole('button', { name: 'Studiofoto schließen' })).toBeFocused();
    await page.keyboard.press('Escape');
    await page.getByLabel('Dein Name').fill('Nele Fiktivtest');
    await expect(link).toBeInViewport({ ratio: 1 });
    await page.setViewportSize({ width, height: 400 });
    await expect(link).toBeInViewport({ ratio: 1 });
  });
}

test('Desktop hat denselben sichtbaren WhatsApp-Kontakt innerhalb der Kopfzeile', async ({
  page,
}) => {
  await page.setViewportSize({ width: 1440, height: 1000 });
  await page.goto('/');
  await expect(page.locator('.floating-whatsapp')).toHaveCount(1);
  await expect(page.locator('.floating-whatsapp')).toBeInViewport({ ratio: 1 });
  await expect(page.locator('.site-header .floating-whatsapp')).toHaveCount(1);
});
