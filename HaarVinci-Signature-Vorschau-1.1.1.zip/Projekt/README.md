# HaarVinci Signature · Vorschau 1.1.1

Weiterentwicklung der bestehenden Astro-Website 1.0.3. Elfenbein, Tiefschwarz, Soft Rosé und sparsame Champagnergold-Akzente; grüne WhatsApp-Kontakte. Kein Neubau und kein Livegang.

**Foto-Freigabe erteilt:** Timo Bockhorn hat die acht Vorher-Nachher-Fotos am 12.11.2026 ausdrücklich freigegeben. Diese aktuelle Anweisung ersetzt die älteren Sperrvermerke; dokumentiert in `content/media-approval.json`.

**Offener Lieferpunkt:** Die acht zugeschnittenen Galerie-JPGs fehlen als importierbare Dateien. Im tatsächlich verfügbaren älteren ZIP sind sie nicht enthalten. Die Bildvorschauen im Chat sind sichtbar, ihre Originaldateien hier aber nicht zugänglich. Die vier neuen Paare sind deshalb noch nicht mit den echten Dateien integriert. Die Vorschau zeigt weiterhin die vorhandenen echten Reel-Standbilder. Keine Ersatz-Kundinnenbilder wurden erzeugt. Benötigt wird nur ein kleines ZIP mit den acht JPGs, keine erneute Foto-Freigabe.

## Ansehen und starten

Die einzelne Datei `HaarVinci-fuer-Conny.html` enthält Bilder, Schriften und Lizenztexte. Nach dem Herunterladen im Browser öffnen. Zum Weitergeben in WhatsApp als Dokument anhängen. Auf GitHub den Download-Pfeil verwenden; der Raw-Endpunkt kann HTML als Quelltext anzeigen. WhatsApp stellt die Datei nicht selbst als Website dar.

Das Vorschau-ZIP vollständig entpacken und `HaarVinci-Vorschau.html` öffnen. `Impressum.html` und `Datenschutz.html` daneben lassen. Das ZIP enthält außerdem die einzelne Conny-Datei, Quellen, Prüfbericht und Bildschirmansichten.

Für die Entwicklung mit Node.js 24 LTS im Ordner `website` beziehungsweise `Projekt`:

```bash
npm ci
npm run dev
```

`http://localhost:4321` öffnen. Für einen statischen Build: `npm run build`, `npm run export:preview`, `npm run preview -- --port 4321 --ignore-lock`. Der normale Hostingbuild steht unter `dist/`, die eingebetteten Dateien unter `offline-preview/`. Kein Backend und keine Datenbank nötig. Telemetrie wird durch den vorhandenen Wrapper deaktiviert.

## Freigegebene neue Galerie importieren

Nach Lieferung und sicherem Entpacken des Übergabe-ZIPs:

```bash
npm run import:signature -- PFAD_ZUM_UEBERGABEORDNER
npm run build
npm run export:preview
```

Der Import prüft zuerst alle acht JPGs gegen die gelieferten SHA-256-Werte. Bereits freigegebene Originale landen in `assets-source/approved-results/`; nach erfolgreicher Prüfung aktiviert er die vorgegebene Paarzuordnung. Der nächste normale Build zeigt dann alle vier Paare. `websiteApproved` ist bereits `true`; `pairConfirmed` bleibt bis zur Dateiprüfung `false`. Der Import erteilt selbst keine Foto-Freigaben.

Für spätere, noch nicht freigegebene Fotos bleibt der getrennte private Vorschaupfad erhalten: Originale unter `.private-media/signature-1.1/`, `npm run build:private`, Ausgabe ausschließlich unter `.private-preview/`. Diese Ordner und `handoff/` bleiben von Git ausgeschlossen. Die Galerie zeigt Vorher und Nachher gleichzeitig, ohne zusätzliche Ausschnittänderung oder Retusche.

## Was umgesetzt ist

- Neue Bildinszenierung im Hero mit vorhandener echter HaarVinci-Arbeit; Ergebnisse früh in der Seite, anschließend dunkler Vertrauensbereich. Originalporträt von Conny mit echten HTML-Texten im Über-Conny-Bereich. Der bestätigte KI-Gestaltungsentwurf bleibt als Quelle erhalten und wird nicht als reale Szene ausgegeben.
- Große Instagram- und Google-Bewertungsbuttons direkt im oberen Bereich. Google führt zur Bewertungssektion mit drei kurzen, gekennzeichneten Auszügen aus den bereitgestellten veröffentlichten Rezensionen. Die Sterne beziehen sich auf die jeweilige Rezension; kein erfundener Gesamtdurchschnitt oder Bewertungszähler. Google-Unternehmensprofil und Bewertungsabgabe bleiben getrennt. Presseverweis zu den Kieler Nachrichten; keine Screenshot-Einbettungen.
- Gut sichtbarer grüner WhatsApp-Kontakt in der angehefteten Kopfzeile ohne JavaScript und ohne zweite Ebene über Texten oder Formularen. Unter 375 Pixeln kompakt als zugängliches Symbol, darüber beschriftet. Beratung und Parkplatzinfo werden erst durch bewusstes Anklicken geöffnet.
- Anfahrt: Eichhofstraße 16, 24116 Kiel, 1. Obergeschoss eines Wohngebäudes; nicht der Imbiss im Erdgeschoss. Separater Kundenstellplatz am Eichkamp nach Absprache. Studio-Route über den bestätigten Link, Parkplatzdetails per vorbereiteter WhatsApp-Anfrage. Kein erfundener zweiter Karten-Pin und keine konkrete unbekannte Stellplatzroute.
- Neun FAQ zuerst, zehn weitere nativ aufklappbar. Sämtliche bisherigen Fach-, Pflege-, Preis-, Formular- und Studio-Galeriefunktionen bleiben erhalten. Die fünf Beratungs-/Bestellschritte und vollständige Material-Vorauszahlung sind unverändert.

## Prüfen

```bash
npm run check
npm run format:check
npm run build
npm run export:preview
npm test
```

Chromium/Playwright, standardmäßig `/usr/bin/chromium`. Andernorts nach `npx playwright install chromium` die Variable `CHROMIUM_PATH=playwright` verwenden. Alle Eingaben sind fiktiv; WhatsApp-/E-Mail-Aktionen werden abgefangen, keine Nachrichten versendet. Details, Grenzen und Ergebnisse: [PRUEFUNG.md](PRUEFUNG.md). Änderungen und Medienstatus: [AENDERUNGEN-1.1.1.md](AENDERUNGEN-1.1.1.md).

## Freigaben und offene Punkte

`content/release.json` bleibt vollständig auf `false`. `npm run build:release` bricht ohne vollständige Freigaben und Rechtstexte ab. Private Bildvorschau und öffentlicher Release sind technisch gegenseitig ausgeschlossen. `noindex` ist kein Zugriffsschutz; private Kundinnenfotos werden deshalb gar nicht in reguläre Auslieferungen geschrieben.

Offen sind die acht Original-JPGs, vollständige Rechtstexte, finaler Hauseingang/Klingelschild sowie genaue Parkplatzzufahrt, Stellplatznummer und Zugangsweg. Foto-Freigabe und Paarzuordnung sind durch die aktuelle Anweisung und das gelieferte Masterbriefing festgelegt. Google-Maps- und Presse-Screenshots bleiben Referenzen; öffentliche Google-Rezensionen werden nur als gekennzeichnete Textauszüge verwendet. Kein IONOS-Upload, keine Domain-, DNS-, Mail- oder Vertragsänderung. Android-, Windows- und Django-App bleiben unberührt.

Die Cloud sperrt direkte `file://`-Navigation. Die tatsächlichen eingebetteten Dateien werden über erlaubtes lokales HTTP ohne weitere Netzabrufe geprüft. Doppelklick, Android-Dateizuordnung und die tatsächliche WhatsApp-Übertragung müssen auf dem privaten Gerät geprüft werden.
