import { spawnSync } from 'node:child_process';
import fs from 'node:fs';
const pairs = JSON.parse(fs.readFileSync('content/paired-results.json', 'utf8'));
const missing = pairs
  .flatMap((p) => [p.before.file, p.after.file])
  .filter(
    (file) =>
      !fs.existsSync(`.private-media/signature-1.1/${file}`) &&
      !fs.existsSync(`assets-source/approved-results/${file}`),
  );
if (missing.length) {
  console.error(
    'Private vollständige Galerie noch nicht baubar. Originaldateien fehlen:\n- ' +
      missing.join('\n- ') +
      '\nZuerst npm run import:signature -- PFAD_ZUM_UEBERGABEORDNER ausführen.',
  );
  process.exit(1);
}
const env = {
  ...process.env,
  ASTRO_TELEMETRY_DISABLED: '1',
  HAARVINCI_RELEASE: 'false',
  HAARVINCI_PRIVATE_PREVIEW: 'true',
  HAARVINCI_PREVIEW_DIST: '.private-preview/dist',
  HAARVINCI_PREVIEW_OUTPUT: '.private-preview/offline',
};
for (const args of [
  ['scripts/prepare-assets.mjs'],
  ['node_modules/astro/bin/astro.mjs', 'build', '--outDir', '.private-preview/dist'],
  ['scripts/export-preview.mjs'],
]) {
  const result = spawnSync(process.execPath, args, { stdio: 'inherit', env });
  if (result.status !== 0) process.exit(result.status || 1);
}
console.log(
  'Vollständige PRIVATE Vorschau unter .private-preview/offline/. Nicht in öffentliche Downloads übernehmen.',
);
