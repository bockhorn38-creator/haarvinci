import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
const root = fileURLToPath(new URL('../', import.meta.url));
const supplied = process.argv[2];
if (!supplied)
  throw new Error('Aufruf: npm run import:signature -- PFAD_ZUM_ENTPACKTEN_UEBERGABEORDNER');
const pairs = JSON.parse(await fs.readFile(path.join(root, 'content/paired-results.json'), 'utf8'));
const ready = [];
for (const entry of pairs.flatMap((pair) =>
  [pair.before, pair.after].map((image) => ({ ...image, approved: pair.websiteApproved === true })),
)) {
  const candidates = [
    path.resolve(supplied, '02_Neue_Ergebnisse/Bereit_zur_Pruefung', entry.file),
    path.resolve(supplied, entry.file),
  ];
  let bytes;
  for (const file of candidates) {
    try {
      bytes = await fs.readFile(file);
      break;
    } catch (error) {
      if (error.code !== 'ENOENT') throw error;
    }
  }
  if (!bytes) throw new Error(`Datei fehlt im Übergabepaket: ${entry.file}`);
  if (createHash('sha256').update(bytes).digest('hex') !== entry.sha256)
    throw new Error(`Prüfsumme stimmt nicht: ${entry.file}. Keine automatische Übernahme.`);
  ready.push({ file: entry.file, bytes, approved: entry.approved });
}
for (const entry of ready) {
  const target = path.join(
    root,
    entry.approved ? 'assets-source/approved-results' : '.private-media/signature-1.1',
  );
  await fs.mkdir(target, { recursive: true });
  await fs.writeFile(path.join(target, entry.file), entry.bytes);
}
// Die Zuordnung stammt aus dem Masterbriefing. Nach erfolgreicher Prüfung
// beider Originaldateien wird sie für bereits ausdrücklich freigegebene Paare aktiviert.
for (const pair of pairs) if (pair.websiteApproved === true) pair.pairConfirmed = true;
const catalogFile = path.join(root, 'content/paired-results.json');
await fs.writeFile(catalogFile + '.tmp', JSON.stringify(pairs, null, 2) + '\n');
await fs.rename(catalogFile + '.tmp', catalogFile);
console.log(
  'Acht Originalbilder und die vorgegebene Zuordnung geprüft. Freigegebene Paare aktiviert; übrige Bilder ausschließlich privat abgelegt. Keine Foto-Freigabe automatisch erteilt.',
);
