import { test, expect } from '@playwright/test';
import {
  readFileSync,
  writeFileSync,
  mkdirSync,
  mkdtempSync,
  cpSync,
  symlinkSync,
  rmSync,
  readdirSync,
  existsSync,
} from 'node:fs';
import { resolve, join } from 'node:path';
import { tmpdir } from 'node:os';
import { createHash } from 'node:crypto';
import { execFileSync, spawnSync } from 'node:child_process';
import sharp from 'sharp';

test('mobile Kopfzeile bleibt bei verzögertem Seiten-JavaScript stabil', async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 });
  let release!: () => void;
  const gate = new Promise<void>((resolve) => {
    release = resolve;
  });
  await page.route('**/_astro/*.js', async (route) => {
    await gate;
    await route.continue();
  });
  await page.goto('/', { waitUntil: 'commit' });
  await expect(page.locator('.header-whatsapp')).toBeInViewport({ ratio: 1 });
  await page.evaluate(() => document.fonts.ready);
  await expect(page.locator('.main-nav')).toBeHidden();
  const before = (await page.locator('.site-header').boundingBox())!;
  release();
  await page.waitForLoadState('networkidle');
  const after = (await page.locator('.site-header').boundingBox())!;
  expect(after.height).toBeCloseTo(before.height, 0);
  await page.getByRole('button', { name: 'Menü', exact: true }).click();
  await expect(page.locator('.main-nav')).toBeVisible();
});

test('Signature ordnet Ergebnisse früh ein und trennt Google-Profil, Bewertungsabgabe und Presse', async ({
  page,
}) => {
  await page.goto('/');
  const sections = await page
    .locator('main > section[id]')
    .evaluateAll((nodes) => nodes.map((node) => node.id));
  expect(sections.indexOf('ergebnisse')).toBeLessThan(sections.indexOf('leistungen'));
  expect(sections.indexOf('vertrauen')).toBeLessThan(sections.indexOf('methode'));
  await expect(
    page.getByRole('link', { name: 'HaarVinci auf Google', exact: true }),
  ).toHaveAttribute('href', 'https://maps.app.goo.gl/KvQ4o5tsqVvmvv2L7?g_st=awb');
  await expect(
    page.getByRole('link', { name: 'Eine Bewertung abgeben', exact: false }),
  ).toHaveAttribute('href', 'https://g.page/r/CWCMg9iC9hN9EBE/review');
  await expect(
    page.getByRole('link', { name: 'Zum Artikel der Kieler Nachrichten', exact: false }),
  ).toHaveAttribute('href', /https:\/\/www\.kn-online\.de\/.*ZLA5S3FALFFUNJHYKYGRSB36Z4.html$/);
  await expect(page.locator('#vertrauen img, #vertrauen iframe')).toHaveCount(0);
  await expect(page.locator('#vertrauen')).not.toContainText(
    /5[,.]0|5\/5|nicht veröffentlicht|Hirntumor/,
  );
  await expect(page.locator('.faq-groups > .faq-list > details')).toHaveCount(9);
  await expect(page.locator('.faq-more')).not.toHaveAttribute('open', '');
  await page.locator('.faq-more > summary').click();
  await expect(page.locator('.faq-more .faq-list > details')).toHaveCount(10);
  await page.locator('.faq-more .faq-list > details').first().locator('summary').click();
  await expect(page.locator('.faq-more .faq-answer').first()).toBeVisible();
});

for (const width of [360, 390, 412, 768]) {
  test(`Anfahrt und grüner WhatsApp-Kontakt bleiben eindeutig bei ${width}px`, async ({ page }) => {
    await page.setViewportSize({ width, height: 850 });
    await page.emulateMedia({ reducedMotion: 'reduce' });
    await page.goto('/');
    const whatsapp = page.locator('.header-whatsapp');
    await expect(whatsapp).toBeInViewport({ ratio: 1 });
    await expect(whatsapp).toHaveCSS('background-color', 'rgb(20, 122, 67)');
    await page.locator('#anfahrt').scrollIntoViewIfNeeded();
    await expect(page.locator('#anfahrt')).toContainText('Eichhofstraße 16, 24116 Kiel');
    await expect(page.locator('.studio-directions')).toContainText('1. Obergeschoss');
    await expect(page.locator('.studio-directions')).toContainText('nicht in den Imbiss');
    await expect(page.locator('#anfahrt')).not.toContainText(
      /Stellplatznummer|kostenlos|garantiert/,
    );
    const route = page.getByRole('link', { name: 'Route zum Studio', exact: true });
    await expect(route).toHaveAttribute(
      'href',
      'https://maps.app.goo.gl/KvQ4o5tsqVvmvv2L7?g_st=awb',
    );
    const parking = page.getByRole('link', {
      name: 'Parkplatzinfo per WhatsApp anfragen',
      exact: true,
    });
    const url = new URL((await parking.getAttribute('href'))!);
    expect(url.origin + url.pathname).toBe('https://wa.me/4917631600586');
    expect(url.searchParams.get('text')).toContain('Zufahrt');
    expect(url.searchParams.get('text')).toContain('Eichkamp');
    await expect(page.locator('.parking-directions a')).toHaveCount(1);
    await expect(page.locator('#anfahrt iframe, #anfahrt img')).toHaveCount(0);
    await page.locator('.site-footer').scrollIntoViewIfNeeded();
    await expect(whatsapp).toBeInViewport({ ratio: 1 });
    expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBeLessThanOrEqual(
      width,
    );
  });
}

test('Freigegebene Galerie wartet auf Originaldateien und der Livegang bleibt getrennt gesperrt', async ({
  page,
}) => {
  await page.goto('/');
  await expect(page.locator('.paired-card')).toHaveCount(0);
  const catalog = JSON.parse(readFileSync('content/paired-results.json', 'utf8'));
  expect(catalog).toHaveLength(4);
  expect(
    catalog.every((item: any) => item.websiteApproved === true && item.pairConfirmed === false),
  ).toBe(true);
  for (const item of catalog) {
    expect(readFileSync('dist/index.html', 'utf8')).not.toContain(item.id);
    expect(readFileSync('offline-preview/HaarVinci-fuer-Conny.html', 'utf8')).not.toContain(
      item.id,
    );
  }
  expect(
    Object.values(JSON.parse(readFileSync('content/release.json', 'utf8'))).every(
      (value) => value === false,
    ),
  ).toBe(true);
  const blocked = spawnSync(process.execPath, ['scripts/check-release.mjs'], {
    env: { ...process.env, HAARVINCI_PRIVATE_PREVIEW: 'true' },
    encoding: 'utf8',
  });
  expect(blocked.status).not.toBe(0);
  expect(blocked.stderr).toContain('private Bildvorschau');
});

test('Galerie-Import, private Einzeldatei und anschließender öffentlicher Build trennen die Bildrechte', async ({
  browser,
}) => {
  test.setTimeout(120_000);
  const temporary = mkdtempSync(join(tmpdir(), 'haarvinci-private-gallery-'));
  const originalCatalog = readFileSync('content/paired-results.json', 'utf8');
  try {
    for (const file of [
      'src',
      'public',
      'scripts',
      'assets-source',
      'content',
      'astro.config.mjs',
      'tsconfig.json',
      'package.json',
    ])
      cpSync(file, join(temporary, file), { recursive: true });
    symlinkSync(
      resolve('node_modules'),
      join(temporary, 'node_modules'),
      process.platform === 'win32' ? 'junction' : 'dir',
    );
    const catalog = JSON.parse(originalCatalog);
    for (const item of catalog) {
      item.websiteApproved = false;
      item.pairConfirmed = false;
    }
    const input = join(temporary, 'fiktive-testbilder');
    mkdirSync(input);
    // Ausschließlich geometrische Testflächen, keine vermeintlichen Kundinnenbilder.
    let index = 0;
    for (const entry of catalog.flatMap((item: any) => [item.before, item.after])) {
      const bytes = await sharp({
        create: {
          width: 240,
          height: 320,
          channels: 3,
          background: { r: 70 + index++ * 15, g: 90, b: 120 },
        },
      })
        .withMetadata({ exif: { IFD0: { Copyright: 'Fiktives Testbild' } } })
        .jpeg()
        .toBuffer();
      entry.sha256 = createHash('sha256').update(bytes).digest('hex');
      writeFileSync(join(input, entry.file), bytes);
    }
    writeFileSync(join(temporary, 'content/paired-results.json'), JSON.stringify(catalog));
    const options = {
      cwd: temporary,
      env: { ...process.env, HAARVINCI_PRIVATE_PREVIEW: 'false', ASTRO_TELEMETRY_DISABLED: '1' },
      stdio: 'pipe' as const,
      timeout: 90_000,
    };
    execFileSync(process.execPath, ['scripts/import-signature.mjs', input], options);
    const beforeImport = readFileSync(
      join(temporary, '.private-media/signature-1.1', catalog[0].before.file),
    );
    writeFileSync(join(input, catalog[0].before.file), 'Manipuliertes Testbild');
    expect(() =>
      execFileSync(process.execPath, ['scripts/import-signature.mjs', input], options),
    ).toThrow();
    expect(
      readFileSync(join(temporary, '.private-media/signature-1.1', catalog[0].before.file)),
    ).toEqual(beforeImport);
    execFileSync(process.execPath, ['scripts/build-private-preview.mjs'], options);
    expect(existsSync(join(temporary, 'dist'))).toBe(false);
    const single = join(temporary, '.private-preview/offline/HaarVinci-fuer-Conny.html');
    const context = await browser.newContext({
      offline: true,
      viewport: { width: 390, height: 844 },
    });
    await context.route('http://127.0.0.1:4322/private-galerie.html', (route) =>
      route.fulfill({ path: single, contentType: 'text/html' }),
    );
    const page = await context.newPage();
    for (const width of [360, 390, 412, 430, 1440]) {
      await page.setViewportSize({ width, height: 900 });
      await page.goto('http://127.0.0.1:4322/private-galerie.html');
      await expect(page.locator('.paired-card')).toHaveCount(4);
      for (const card of await page.locator('.paired-card').all()) {
        await card.scrollIntoViewIfNeeded();
        await expect(card.getByText('Vorher', { exact: true })).toBeVisible();
        await expect(card.getByText('Nachher', { exact: true })).toBeVisible();
        const images = card.locator('img');
        for (const img of await images.all()) {
          await img.evaluate((e: HTMLImageElement) => e.decode());
          const bounds = (await img.boundingBox())!;
          expect(bounds.width / bounds.height).toBeCloseTo(240 / 320, 2);
          const bytes = Buffer.from((await img.getAttribute('src'))!.split(',')[1], 'base64');
          expect((await sharp(bytes).metadata()).exif).toBeUndefined();
        }
        const before = (await images.nth(0).boundingBox())!;
        const after = (await images.nth(1).boundingBox())!;
        expect(before.x + before.width).toBeLessThanOrEqual(after.x);
      }
      expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBeLessThanOrEqual(
        width,
      );
    }
    await context.close();
    const unsafe = spawnSync(
      process.execPath,
      ['node_modules/astro/bin/astro.mjs', 'build', '--outDir', 'dist'],
      {
        ...options,
        env: { ...options.env, HAARVINCI_PRIVATE_PREVIEW: 'true' },
        encoding: 'utf8',
      },
    );
    expect(unsafe.status).not.toBe(0);
    expect(unsafe.stderr).toContain('Private Galerie');
    expect(existsSync(join(temporary, 'dist/index.html'))).toBe(false);
    const unsafeExport = spawnSync(process.execPath, ['scripts/export-preview.mjs'], {
      ...options,
      env: {
        ...options.env,
        HAARVINCI_PREVIEW_DIST: '.private-preview/dist',
        HAARVINCI_PREVIEW_OUTPUT: 'offline-preview',
      },
      encoding: 'utf8',
    });
    expect(unsafeExport.status).not.toBe(0);
    expect(unsafeExport.stderr).toContain('Private Bildvorschauen');
    execFileSync(process.execPath, ['node_modules/astro/bin/astro.mjs', 'build'], options);
    const publicHome = readFileSync(join(temporary, 'dist/index.html'), 'utf8');
    for (const item of catalog) expect(publicHome).not.toContain(item.id);
    expect(
      readdirSync(join(temporary, 'public/medien')).some((name) =>
        /aschblond|rotbraun|goldblond|weihnacht/.test(name),
      ),
    ).toBe(false);
    // Nach ausdrücklicher Freigabe aktiviert derselbe Import die geprüften Paare.
    writeFileSync(join(input, catalog[0].before.file), beforeImport);
    for (const item of catalog) item.websiteApproved = true;
    writeFileSync(join(temporary, 'content/paired-results.json'), JSON.stringify(catalog));
    execFileSync(process.execPath, ['scripts/import-signature.mjs', input], options);
    const activated = JSON.parse(
      readFileSync(join(temporary, 'content/paired-results.json'), 'utf8'),
    );
    expect(activated.every((item: any) => item.websiteApproved && item.pairConfirmed)).toBe(true);
    execFileSync(process.execPath, ['node_modules/astro/bin/astro.mjs', 'build'], options);
    const approvedHome = readFileSync(join(temporary, 'dist/index.html'), 'utf8');
    for (const item of catalog) expect(approvedHome).toContain(item.id);
  } finally {
    rmSync(temporary, { recursive: true, force: true });
    expect(readFileSync('content/paired-results.json', 'utf8')).toBe(originalCatalog);
  }
});
