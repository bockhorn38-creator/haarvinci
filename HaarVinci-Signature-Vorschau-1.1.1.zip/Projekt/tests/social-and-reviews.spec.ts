import { test, expect } from '@playwright/test';

test('Instagram und Google sind im oberen Bereich große, funktionierende Einstiege', async ({
  page,
}) => {
  for (const width of [360, 390, 412, 768, 1440]) {
    await page.setViewportSize({ width, height: 950 });
    await page.emulateMedia({ reducedMotion: 'reduce' });
    await page.goto('/');
    const instagram = page
      .locator('.hero-social')
      .getByRole('link', { name: 'Instagram ansehen', exact: true });
    const google = page
      .locator('.hero-social')
      .getByRole('link', { name: 'Google-Bewertungen', exact: true });
    await expect(instagram).toBeVisible();
    await expect(instagram).toHaveAttribute('href', 'https://www.instagram.com/haarvinci/');
    await expect(instagram).toHaveAttribute('rel', 'noopener noreferrer');
    for (const link of [instagram, google]) {
      const box = (await link.boundingBox())!;
      expect(box.height).toBeGreaterThanOrEqual(48);
      expect(box.x).toBeGreaterThanOrEqual(0);
      expect(box.x + box.width).toBeLessThanOrEqual(width);
    }
    await google.click();
    await expect(page).toHaveURL(/#bewertungen$/);
    await expect(page.locator('#google-reviews-title')).toBeInViewport();
    await expect(page.locator('.review-card')).toHaveCount(3);
    expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBeLessThanOrEqual(
      width,
    );
  }
});

test('bereitgestellte Google-Stimmen erscheinen als gekennzeichnete Auszüge statt als erfundener Gesamtschnitt', async ({
  page,
}) => {
  await page.goto('/');
  const reviews = page.locator('#bewertungen');
  await reviews.scrollIntoViewIfNeeded();
  await expect(reviews).toContainText('Ausgewählte Google-Rezensionen, gekürzt wiedergegeben.');
  await expect(reviews.locator('blockquote')).toHaveCount(3);
  await expect(
    reviews.getByRole('img', { name: '5 von 5 Sternen in dieser Rezension' }),
  ).toHaveCount(3);
  await expect(reviews).toContainText(
    'Conny ist unglaublich nett, herzlich und nimmt sich viel Zeit für eine ehrliche Beratung.',
  );
  await expect(reviews).toContainText('Conny hat mir schönes neues Haar gezaubert!');
  await expect(reviews).toContainText('Beste Frisuren ever, eine tolle Frau mit Herz von Gold.');
  await expect(reviews.locator('img, iframe')).toHaveCount(0);
  await expect(reviews).not.toContainText(
    /nicht veröffentlicht|Hirntumor|live aktualisiert|Gesamtbewertung/i,
  );
  const structured = await page.locator('script[type="application/ld+json"]').allTextContents();
  expect(structured.join('')).not.toMatch(/AggregateRating|reviewCount/);
  await expect(
    page.getByRole('link', { name: 'HaarVinci auf Google', exact: true }),
  ).toHaveAttribute('href', 'https://maps.app.goo.gl/KvQ4o5tsqVvmvv2L7?g_st=awb');
  await expect(
    page.getByRole('link', { name: 'Eine Bewertung abgeben', exact: true }),
  ).toHaveAttribute('href', 'https://g.page/r/CWCMg9iC9hN9EBE/review');
});
